# Plugin Icon

Place a 128x128 PNG icon here named `Icon128.png` for the plugin's visual representation in the Unreal Editor plugins window.

The icon should:
- Be 128x128 pixels
- Be in PNG format
- Represent VRM/avatar content
- Follow Unreal Engine's visual style guidelines

For now, a placeholder can be used or the default Unreal Engine plugin icon will be shown.
