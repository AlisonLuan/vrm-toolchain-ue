#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <variant>
#include <span>

namespace vrm_glb_parser {

// Error codes for GLB parsing operations
enum class ErrorCode {
    Success = 0,
    FileNotFound,
    FileTooSmall,
    InvalidMagic,
    InvalidVersion,
    InvalidLength,
    InvalidChunkLength,
    InvalidChunkType,
    MissingJsonChunk,
    JsonChunkNotFirst,
    InvalidJsonData,
    InvalidUtf8,
    UnexpectedEndOfFile,
    IoError
};

// Convert error code to human-readable string
const char* error_code_to_string(ErrorCode code) noexcept;

// Result type for operations that can fail (C++20 compatible)
template<typename T>
class [[nodiscard]] Result {
public:
    // Constructors
    Result(const T& value) : data_(value) {}
    Result(T&& value) : data_(std::move(value)) {}
    Result(ErrorCode error) : data_(error) {}
    
    // Check if result contains a value
    [[nodiscard]] bool has_value() const noexcept {
        return std::holds_alternative<T>(data_);
    }
    
    [[nodiscard]] explicit operator bool() const noexcept {
        return has_value();
    }
    
    // Access value
    [[nodiscard]] const T& value() const & {
        return std::get<T>(data_);
    }
    
    [[nodiscard]] T& value() & {
        return std::get<T>(data_);
    }
    
    [[nodiscard]] T&& value() && {
        return std::get<T>(std::move(data_));
    }
    
    // Access error
    [[nodiscard]] ErrorCode error() const {
        return std::get<ErrorCode>(data_);
    }
    
private:
    std::variant<T, ErrorCode> data_;
};

// VRM version enumeration
enum class VrmVersion {
    None,      // Not a VRM file or no VRM extension found
    VRM0,      // VRM 0.x (uses "VRM" extension)
    VRM1       // VRM 1.x (uses "VRMC_vrm" extension)
};

// VRM extension data with presence indicator
struct VrmExtensionData {
    std::string json_data;  // Raw JSON string of the VRM extension
    bool present;           // true if extension was found, false if not present
    
    // Convenience constructor
    VrmExtensionData(std::string data = "", bool is_present = false) 
        : json_data(std::move(data)), present(is_present) {}
};

// GLB header structure (12 bytes)
struct GlbHeader {
    uint32_t magic;      // Must be 0x46546C67 ("glTF" in ASCII)
    uint32_t version;    // Must be 2 for GLB v2
    uint32_t length;     // Total file length including header
};

// Constants for chunk types
constexpr uint32_t CHUNK_TYPE_JSON = 0x4E4F534A;  // "JSON" in little-endian
constexpr uint32_t CHUNK_TYPE_BIN = 0x004E4942;   // "BIN\0" in little-endian
constexpr uint32_t GLB_MAGIC = 0x46546C67;        // "glTF" in little-endian
constexpr uint32_t GLB_VERSION_2 = 2;

// GLB structure size constants
constexpr size_t GLB_HEADER_SIZE = 12;            // Size of GLB header in bytes
constexpr size_t CHUNK_HEADER_SIZE = 8;           // Size of chunk header in bytes

/**
 * Extract the glTF JSON chunk from a GLB file.
 * 
 * @param filepath Path to the .glb or .vrm file
 * @return JSON string on success, or ErrorCode on failure
 */
Result<std::string> ExtractGltfJsonFromGlbFile(const std::string& filepath);

/**
 * Extract the glTF JSON chunk from GLB data in memory.
 * 
 * @param data Span of bytes containing GLB file data
 * @return JSON string on success, or ErrorCode on failure
 */
Result<std::string> ExtractGltfJsonFromGlbBytes(std::span<const uint8_t> data);

/**
 * Detect VRM version from glTF JSON string.
 * Checks for "VRM" extension (VRM 0.x) or "VRMC_vrm" extension (VRM 1.x).
 * 
 * @param gltf_json The glTF JSON string (typically from ExtractGltfJsonFromGlb*)
 * @return VrmVersion indicating the version detected
 */
VrmVersion DetectVrmVersion(const std::string& gltf_json);

/**
 * Parse VRM 0.x extension data from glTF JSON.
 * 
 * @param gltf_json The glTF JSON string
 * @return Result containing VrmExtensionData on success (with present flag),
 *         or ErrorCode if JSON parsing failed
 */
Result<VrmExtensionData> ParseVrm0Raw(const std::string& gltf_json);

/**
 * Parse VRM 1.x extension data from glTF JSON.
 * 
 * @param gltf_json The glTF JSON string
 * @return Result containing VrmExtensionData on success (with present flag),
 *         or ErrorCode if JSON parsing failed
 */
Result<VrmExtensionData> ParseVrm1Raw(const std::string& gltf_json);

} // namespace vrm_glb_parser
