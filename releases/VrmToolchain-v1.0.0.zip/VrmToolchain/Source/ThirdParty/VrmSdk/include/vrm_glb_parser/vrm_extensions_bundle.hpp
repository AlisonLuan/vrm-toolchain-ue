#pragma once

#include <string>
#include <map>
#include "vrm_glb_parser/glb_parser.hpp"

namespace vrm_glb_parser {

// Map of extension names to their raw JSON data
// Using std::map for deterministic ordering
using ExtensionsMap = std::map<std::string, VrmExtensionData>;

/**
 * Bundle containing all VRM-related extensions extracted from a GLB file.
 * 
 * This structure aggregates multiple extension blocks (e.g., "VRMC_vrm", "VRM",
 * "VRMC_springBone", "VRMC_materials_mtoon") into a single container for easy
 * consumption by downstream normalizers.
 */
struct VrmExtensionsBundle {
    // Raw extension blocks by name, e.g. "VRMC_vrm", "VRM", "VRMC_materials_mtoon", etc.
    ExtensionsMap extensions;

    /**
     * Check if any VRM extension is present (either VRM0 or VRM1).
     * @return true if VRMC_vrm or VRM extension is present
     */
    bool has_any_vrm() const {
        return has_vrm1() || has_vrm0();
    }

    /**
     * Check if VRM 1.x extension is present.
     * @return true if VRMC_vrm extension is present
     */
    bool has_vrm1() const {
        auto it = extensions.find("VRMC_vrm");
        return it != extensions.end() && it->second.present;
    }

    /**
     * Check if VRM 0.x extension is present.
     * @return true if VRM extension is present
     */
    bool has_vrm0() const {
        auto it = extensions.find("VRM");
        return it != extensions.end() && it->second.present;
    }
};

/**
 * Extract all VRM-related extensions from a GLB file.
 * 
 * This function extracts the following extensions if present:
 * - "VRMC_vrm" (VRM 1.x)
 * - "VRM" (VRM 0.x)
 * - "VRMC_springBone"
 * - "VRMC_materials_mtoon"
 * - "VRMC_node_constraint"
 * - Other VRMC_* extensions found in the root extensions object
 * 
 * @param filepath Path to the .glb or .vrm file
 * @return Result containing VrmExtensionsBundle on success, or ErrorCode on failure
 * 
 * Error semantics:
 * - If GLB JSON chunk is invalid JSON → ErrorCode::InvalidJsonData
 * - If JSON is valid but no VRM extensions are present → success with empty extensions map
 * - Parse error and "not present" remain distinct
 */
Result<VrmExtensionsBundle> ExtractVrmExtensionsBundleFromGlbFile(const std::string& filepath);

/**
 * Extract all VRM-related extensions from GLB data in memory.
 * 
 * This function extracts the following extensions if present:
 * - "VRMC_vrm" (VRM 1.x)
 * - "VRM" (VRM 0.x)
 * - "VRMC_springBone"
 * - "VRMC_materials_mtoon"
 * - "VRMC_node_constraint"
 * - Other VRMC_* extensions found in the root extensions object
 * 
 * @param data Pointer to GLB data bytes
 * @param size Size of the GLB data in bytes
 * @return Result containing VrmExtensionsBundle on success, or ErrorCode on failure
 * 
 * Error semantics:
 * - If GLB JSON chunk is invalid JSON → ErrorCode::InvalidJsonData
 * - If JSON is valid but no VRM extensions are present → success with empty extensions map
 * - Parse error and "not present" remain distinct
 */
Result<VrmExtensionsBundle> ExtractVrmExtensionsBundleFromGlbBytes(const uint8_t* data, size_t size);

} // namespace vrm_glb_parser
