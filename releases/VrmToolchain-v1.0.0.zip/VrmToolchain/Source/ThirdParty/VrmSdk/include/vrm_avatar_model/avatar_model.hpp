#pragma once

#include "avatar_meta.hpp"
#include "humanoid_mapping.hpp"
#include "expression.hpp"
#include "material.hpp"
#include "spring_bone.hpp"
#include "constraints.hpp"

#include <optional>
#include <vector>
#include <map>
#include <string>

namespace vrm_avatar_model {

/// Map of extension name to raw JSON string
/// Example keys: "VRMC_vrm", "VRMC_materials_mtoon"
/// Values are opaque JSON strings (not parsed at this layer)
/// Uses std::map for deterministic ordering
using ExtensionMap = std::map<std::string, std::string>;

/// Top-level avatar model with optional sections
/// This is the canonical data model for VRM avatars
struct AvatarModel {
    /// Avatar metadata and licensing information
    /// This field is always present, but individual meta fields may be empty or defaulted.
    /// No validation is performed at this layer - use higher-level validators as needed.
    AvatarMeta meta;
    
    /// Optional: Humanoid bone mapping
    /// Maps standard humanoid bones to nodes in the underlying 3D model
    std::optional<HumanoidMapping> humanoid;
    
    /// Optional: Facial expressions and blendshapes
    /// Defines all expressions/blendshapes for the avatar
    std::optional<ExpressionSet> expressions;
    
    /// Optional: Material descriptors
    /// Describes materials used by the avatar (e.g., MToon shader parameters)
    std::optional<std::vector<Material>> materials;
    
    /// Optional: Spring bone configuration
    /// Physics simulation for hair, clothes, etc.
    std::optional<SpringBoneConfig> spring_bones;
    
    /// Optional: Constraint definitions
    /// Defines various constraints between nodes
    std::optional<ConstraintSet> constraints;
    
    /// Optional: Specifies the version of the VRM specification this model conforms to
    std::optional<std::string> vrm_version;
    
    /// Raw extension JSON by extension name
    /// Always present; empty map means no extensions stored.
    /// Stores unknown or future VRM extensions in a structured, version-agnostic way.
    /// Keys are extension names (e.g., "VRMC_vrm", "VRMC_materials_mtoon").
    /// Values are opaque JSON strings preserved as-is - no parsing performed at this layer.
    /// Uses std::map for deterministic ordering.
    ExtensionMap extensions;
};

} // namespace vrm_avatar_model
