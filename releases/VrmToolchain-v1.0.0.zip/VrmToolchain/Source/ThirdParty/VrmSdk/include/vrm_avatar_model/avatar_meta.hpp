#pragma once

#include <string>
#include <optional>
#include <vector>

namespace vrm_avatar_model {

/// Allowed user permissions for avatar usage
enum class AllowedUser {
    OnlyAuthor,
    ExplicitlyLicensedPerson,
    Everyone
};

/// Avatar license type
enum class LicenseType {
    Redistribution_Prohibited,
    CC0,
    CC_BY,
    CC_BY_NC,
    CC_BY_SA,
    CC_BY_NC_SA,
    CC_BY_ND,
    CC_BY_NC_ND,
    Other
};

/// Commercial usage permissions
enum class CommercialUsage {
    Disallow,
    Allow
};

/// Violent content usage permissions
enum class ViolentUsage {
    Disallow,
    Allow
};

/// Sexual content usage permissions
enum class SexualUsage {
    Disallow,
    Allow
};

/// Avatar metadata including title, author, and licensing information
struct AvatarMeta {
    /// Avatar title/name
    std::string title;
    
    /// Version of the avatar model
    std::optional<std::string> version;
    
    /// Author/creator name
    std::optional<std::string> author;
    
    /// Contact information
    std::optional<std::string> contact_information;
    
    /// Reference/source information
    std::optional<std::string> reference;
    
    /// Thumbnail image reference (path or URL)
    std::optional<std::string> thumbnail;
    
    /// Who is allowed to use this avatar
    AllowedUser allowed_user = AllowedUser::OnlyAuthor;
    
    /// License type
    LicenseType license_type = LicenseType::Redistribution_Prohibited;
    
    /// Other license name (when license_type is Other)
    std::optional<std::string> other_license_name;
    
    /// Other license URL
    std::optional<std::string> other_license_url;
    
    /// Commercial usage permission
    CommercialUsage commercial_usage = CommercialUsage::Disallow;
    
    /// Violent usage permission
    ViolentUsage violent_usage = ViolentUsage::Disallow;
    
    /// Sexual usage permission
    SexualUsage sexual_usage = SexualUsage::Disallow;
    
    /// Other permission information
    std::optional<std::string> other_permission_info;
    
    /// Credits/attribution text
    std::optional<std::string> credits;
};

} // namespace vrm_avatar_model
