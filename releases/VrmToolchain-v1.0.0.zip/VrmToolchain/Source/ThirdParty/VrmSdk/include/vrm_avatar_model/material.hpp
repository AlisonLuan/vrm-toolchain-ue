#pragma once

#include <string>
#include <optional>
#include <array>

namespace vrm_avatar_model {

/// Rendering mode for materials
enum class RenderMode {
    Opaque,
    Cutout,
    Transparent,
    TransparentWithZWrite
};

/// Cull mode for materials
enum class CullMode {
    Off,    // Two-sided rendering
    Front,
    Back
};

/// Outline width mode
enum class OutlineWidthMode {
    None,
    WorldCoordinates,
    ScreenCoordinates
};

/// Outline color mode
enum class OutlineColorMode {
    FixedColor,
    MixedLighting
};

/// MToon material parameters (VRM's toon shader specification)
struct MToonMaterial {
    /// Material name
    std::string name;
    
    /// Render queue order
    std::optional<int> render_queue;
    
    /// Rendering mode
    RenderMode render_mode = RenderMode::Opaque;
    
    /// Cull mode
    CullMode cull_mode = CullMode::Back;
    
    /// Base color (RGBA)
    std::array<float, 4> base_color = {1.0f, 1.0f, 1.0f, 1.0f};
    
    /// Base texture name/path
    std::optional<std::string> base_texture;
    
    /// Shade color (for toon shading)
    std::optional<std::array<float, 3>> shade_color;
    
    /// Shade texture
    std::optional<std::string> shade_texture;
    
    /// Cutout threshold (for cutout rendering)
    float cutoff = 0.5f;
    
    /// Shading shift value
    float shading_shift = 0.0f;
    
    /// Shading toony value (0.0 = realistic, 1.0 = toon)
    float shading_toony = 0.9f;
    
    /// Light color attenuation
    float light_color_attenuation = 0.0f;
    
    /// Indirect light intensity
    float indirect_light_intensity = 0.1f;
    
    /// Rim color
    std::optional<std::array<float, 3>> rim_color;
    
    /// Rim texture
    std::optional<std::string> rim_texture;
    
    /// Rim lighting mix
    float rim_lighting_mix = 1.0f;
    
    /// Rim fresnel power
    float rim_fresnel_power = 5.0f;
    
    /// Rim lift
    float rim_lift = 0.0f;
    
    /// Outline width mode
    OutlineWidthMode outline_width_mode = OutlineWidthMode::None;
    
    /// Outline width
    float outline_width = 0.0f;
    
    /// Outline color
    std::optional<std::array<float, 3>> outline_color;
    
    /// Outline color mode
    OutlineColorMode outline_color_mode = OutlineColorMode::FixedColor;
    
    /// Outline lighting mix
    float outline_lighting_mix = 1.0f;
    
    /// Normal map texture
    std::optional<std::string> normal_texture;
    
    /// Normal map scale
    float normal_scale = 1.0f;
    
    /// Emissive color
    std::optional<std::array<float, 3>> emissive_color;
    
    /// Emissive texture
    std::optional<std::string> emissive_texture;
    
    /// Matcap texture (sphere texture for additional lighting)
    std::optional<std::string> matcap_texture;
    
    /// UV animation mask texture
    std::optional<std::string> uv_animation_mask_texture;
    
    /// UV animation scroll speed (X, Y)
    std::optional<std::array<float, 2>> uv_animation_scroll;
    
    /// UV animation rotation speed
    float uv_animation_rotation = 0.0f;
};

/// Generic material descriptor (can be extended for other shader types)
struct Material {
    /// Material name
    std::string name;
    
    /// Shader type identifier
    std::string shader;
    
    /// MToon parameters (if shader is MToon)
    std::optional<MToonMaterial> mtoon;
    
    /// Extensions for other material types can be added here
};

} // namespace vrm_avatar_model
