#pragma once

#include <string>
#include <vector>
#include <array>
#include <optional>

namespace vrm_avatar_model {

/// Axis for constraints
enum class Axis {
    X,
    Y,
    Z
};

/// Roll constraint - constrains rotation around an axis
struct RollConstraint {
    /// Source node that drives the constraint
    std::string source_node;
    
    /// Destination node that is constrained
    std::string destination_node;
    
    /// Roll axis
    Axis roll_axis = Axis::X;
    
    /// Weight of the constraint (0.0 to 1.0)
    float weight = 1.0f;
};

/// Aim constraint - makes a node point toward a target
struct AimConstraint {
    /// Source node (target to aim at)
    std::string source_node;
    
    /// Destination node that aims at the source
    std::string destination_node;
    
    /// Aim axis (which axis points at target)
    Axis aim_axis = Axis::Z;
    
    /// Weight of the constraint (0.0 to 1.0)
    float weight = 1.0f;
};

/// Rotation constraint - copies rotation from one node to another
struct RotationConstraint {
    /// Source node that drives the rotation
    std::string source_node;
    
    /// Destination node that is constrained
    std::string destination_node;
    
    /// Weight of the constraint (0.0 to 1.0)
    float weight = 1.0f;
    
    /// Optional: freeze axes (which axes to freeze)
    std::optional<std::array<bool, 3>> freeze_axes;
};

/// Collection of all constraints for the avatar
struct ConstraintSet {
    /// Roll constraints
    std::vector<RollConstraint> roll_constraints;
    
    /// Aim constraints
    std::vector<AimConstraint> aim_constraints;
    
    /// Rotation constraints
    std::vector<RotationConstraint> rotation_constraints;
};

} // namespace vrm_avatar_model
