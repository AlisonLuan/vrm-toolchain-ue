#pragma once

#include <string>
#include <vector>
#include <optional>
#include <array>

namespace vrm_avatar_model {

/// Target for a morph/blend value (mesh and morph target index)
struct MorphTarget {
    /// The mesh/node name that contains the morph target
    std::string node;
    
    /// The morph target index within the mesh
    int index;
    
    /// The weight/influence of this morph target (0.0 to 1.0)
    float weight;
};

/// Material color override for an expression
struct MaterialColorBinding {
    /// The material name or index
    std::string material;
    
    /// The property name to bind (e.g., "_Color", "_EmissionColor")
    std::string property_name;
    
    /// Target RGBA color values
    std::array<float, 4> target_value;
};

/// Texture transform override for an expression
struct MaterialTextureBinding {
    /// The material name or index
    std::string material;
    
    /// The texture property name
    std::string property_name;
    
    /// Scale for the texture
    std::optional<std::array<float, 2>> scale;
    
    /// Offset for the texture
    std::optional<std::array<float, 2>> offset;
};

/// Expression preset types (standard facial expressions)
enum class ExpressionPreset {
    Custom,      // User-defined expression
    Happy,
    Angry,
    Sad,
    Relaxed,
    Surprised,
    Aa,          // Mouth shape for 'aa' sound
    Ih,          // Mouth shape for 'ih' sound
    Ou,          // Mouth shape for 'ou' sound
    Ee,          // Mouth shape for 'ee' sound
    Oh,          // Mouth shape for 'oh' sound
    Blink,
    BlinkLeft,
    BlinkRight,
    LookUp,
    LookDown,
    LookLeft,
    LookRight,
    Neutral
};

/// Expression override mode
enum class ExpressionOverrideType {
    None,   // No override
    Block,  // Block other expressions
    Blend   // Blend with other expressions
};

/// A single expression/blendshape configuration
struct Expression {
    /// Name of the expression
    std::string name;
    
    /// Preset type (if applicable)
    ExpressionPreset preset = ExpressionPreset::Custom;
    
    /// Morph targets that make up this expression
    std::vector<MorphTarget> morph_target_bindings;
    
    /// Material color bindings for this expression
    std::vector<MaterialColorBinding> material_color_bindings;
    
    /// Material texture bindings for this expression
    std::vector<MaterialTextureBinding> material_texture_bindings;
    
    /// Whether this expression can override blink
    ExpressionOverrideType override_blink = ExpressionOverrideType::None;
    
    /// Whether this expression can override look-at
    ExpressionOverrideType override_look_at = ExpressionOverrideType::None;
    
    /// Whether this expression can override mouth movements
    ExpressionOverrideType override_mouth = ExpressionOverrideType::None;
    
    /// Whether this expression is binary (on/off) or continuous (0.0 to 1.0)
    bool is_binary = false;
};

/// Collection of all expressions for the avatar
struct ExpressionSet {
    /// All expressions defined for this avatar
    std::vector<Expression> expressions;
};

} // namespace vrm_avatar_model
