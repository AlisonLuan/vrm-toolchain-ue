#pragma once

/// VRM Avatar Model - Header-only C++20 canonical avatar model library
/// 
/// This library provides a stable, version-independent data model for VRM avatars.
/// It serves as the interface between VRM parsers and engine integrations.
/// 
/// Usage:
///   #include <vrm_avatar_model/vrm_avatar_model.hpp>
///   
///   vrm_avatar_model::AvatarModel avatar;
///   avatar.meta.title = "My Avatar";
///   avatar.humanoid = vrm_avatar_model::HumanoidMapping{};
///   // ... configure avatar
/// 
/// All components are optional except the meta section.
/// This allows incremental construction and partial avatar definitions.

// Core data structures
#include "avatar_meta.hpp"
#include "humanoid_mapping.hpp"
#include "expression.hpp"
#include "material.hpp"
#include "spring_bone.hpp"
#include "constraints.hpp"
#include "avatar_model.hpp"

// Version information
namespace vrm_avatar_model {
    constexpr int VERSION_MAJOR = 1;
    constexpr int VERSION_MINOR = 0;
    constexpr int VERSION_PATCH = 0;
    
    constexpr const char* VERSION_STRING = "1.0.0";
}
