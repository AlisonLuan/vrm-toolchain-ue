#pragma once

#include <string>
#include <optional>
#include <vector>
#include <array>

namespace vrm_avatar_model {

/// Standard humanoid bone names based on VRM specification
enum class HumanoidBone {
    // Torso
    Hips,
    Spine,
    Chest,
    UpperChest,
    Neck,
    Head,
    
    // Left leg
    LeftUpperLeg,
    LeftLowerLeg,
    LeftFoot,
    LeftToes,
    
    // Right leg
    RightUpperLeg,
    RightLowerLeg,
    RightFoot,
    RightToes,
    
    // Left arm
    LeftShoulder,
    LeftUpperArm,
    LeftLowerArm,
    LeftHand,
    
    // Right arm
    RightShoulder,
    RightUpperArm,
    RightLowerArm,
    RightHand,
    
    // Left hand fingers
    LeftThumbProximal,
    LeftThumbIntermediate,
    LeftThumbDistal,
    LeftIndexProximal,
    LeftIndexIntermediate,
    LeftIndexDistal,
    LeftMiddleProximal,
    LeftMiddleIntermediate,
    LeftMiddleDistal,
    LeftRingProximal,
    LeftRingIntermediate,
    LeftRingDistal,
    LeftLittleProximal,
    LeftLittleIntermediate,
    LeftLittleDistal,
    
    // Right hand fingers
    RightThumbProximal,
    RightThumbIntermediate,
    RightThumbDistal,
    RightIndexProximal,
    RightIndexIntermediate,
    RightIndexDistal,
    RightMiddleProximal,
    RightMiddleIntermediate,
    RightMiddleDistal,
    RightRingProximal,
    RightRingIntermediate,
    RightRingDistal,
    RightLittleProximal,
    RightLittleIntermediate,
    RightLittleDistal,
    
    // Eyes
    LeftEye,
    RightEye,
    
    // Jaw
    Jaw
};

/// Mapping of a humanoid bone to a node/joint in the model
struct BoneMapping {
    /// The standard humanoid bone
    HumanoidBone bone;
    
    /// The node/joint index or name in the underlying 3D model
    std::string node;
    
    /// Optional: when true, use default/recommended values for this bone mapping
    /// instead of custom rotation limits. When std::nullopt, implementation-specific defaults apply.
    std::optional<bool> use_default_values;
    
    /// Optional: min limit for rotation (in degrees)
    std::optional<std::array<float, 3>> min;
    
    /// Optional: max limit for rotation (in degrees)
    std::optional<std::array<float, 3>> max;
    
    /// Optional: center position for rotation
    std::optional<std::array<float, 3>> center;
    
    /// Optional: axis length
    std::optional<float> axis_length;
};

/// Humanoid bone mapping configuration
struct HumanoidMapping {
    /// List of bone mappings from humanoid bones to model nodes
    std::vector<BoneMapping> bone_mappings;
    
    /// Optional: Arm stretch (0.0 to 1.0, default 0.05)
    float arm_stretch = 0.05f;
    
    /// Optional: Leg stretch (0.0 to 1.0, default 0.05)
    float leg_stretch = 0.05f;
    
    /// Optional: Upper arm twist (0.0 to 1.0, default 0.5)
    float upper_arm_twist = 0.5f;
    
    /// Optional: Lower arm twist (0.0 to 1.0, default 0.5)
    float lower_arm_twist = 0.5f;
    
    /// Optional: Upper leg twist (0.0 to 1.0, default 0.5)
    float upper_leg_twist = 0.5f;
    
    /// Optional: Lower leg twist (0.0 to 1.0, default 0.5)
    float lower_leg_twist = 0.5f;
    
    /// Optional: Feet spacing (in meters, default 0.0)
    float feet_spacing = 0.0f;
    
    /// Optional: Has translation degree of freedom
    bool has_translation_dof = false;
};

} // namespace vrm_avatar_model
