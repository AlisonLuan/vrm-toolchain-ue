#pragma once

#include <string>
#include <vector>
#include <array>
#include <optional>

namespace vrm_avatar_model {

/// Sphere collider for spring bone collision detection
struct SphereCollider {
    /// Node/bone that the collider is attached to
    std::optional<std::string> node;
    
    /// Offset from the node position
    std::array<float, 3> offset = {0.0f, 0.0f, 0.0f};
    
    /// Radius of the sphere
    float radius = 0.0f;
};

/// Capsule collider for spring bone collision detection
struct CapsuleCollider {
    /// Node/bone that the collider is attached to
    std::optional<std::string> node;
    
    /// Offset of the first end from the node position
    std::array<float, 3> offset_start = {0.0f, 0.0f, 0.0f};
    
    /// Offset of the second end from the node position
    std::array<float, 3> offset_end = {0.0f, 0.0f, 0.0f};
    
    /// Radius of the capsule
    float radius = 0.0f;
};

/// Collider group containing multiple colliders
struct ColliderGroup {
    /// Name of the collider group
    std::string name;
    
    /// Sphere colliders in this group
    std::vector<SphereCollider> sphere_colliders;
    
    /// Capsule colliders in this group
    std::vector<CapsuleCollider> capsule_colliders;
};

/// A single spring bone joint
struct SpringBoneJoint {
    /// The node/bone this joint controls
    std::string node;
    
    /// Hit radius for collision detection
    float hit_radius = 0.0f;
    
    /// Stiffness of the spring (0.0 to 1.0, higher = more rigid)
    float stiffness = 1.0f;
    
    /// Gravity power applied to this joint
    std::array<float, 3> gravity_power = {0.0f, -1.0f, 0.0f};
    
    /// Gravity direction (normalized)
    std::array<float, 3> gravity_dir = {0.0f, -1.0f, 0.0f};
    
    /// Drag force (0.0 to 1.0, higher = more damping)
    float drag_force = 0.4f;
};

/// A spring bone chain (series of joints)
struct SpringBoneChain {
    /// Name/comment for this chain
    std::optional<std::string> comment;
    
    /// Root node of the chain
    std::string root_node;
    
    /// Joints in the chain
    std::vector<SpringBoneJoint> joints;
    
    /// Names of collider groups that affect this chain
    std::vector<std::string> collider_groups;
    
    /// Center node for the spring bone (optional, for rotation calculation)
    std::optional<std::string> center;
};

/// Spring bone configuration for the avatar
struct SpringBoneConfig {
    /// All collider groups
    std::vector<ColliderGroup> collider_groups;
    
    /// All spring bone chains
    std::vector<SpringBoneChain> chains;
};

} // namespace vrm_avatar_model
