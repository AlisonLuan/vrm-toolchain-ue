#pragma once

/// Optional JSON serialization helpers for VRM Avatar Model
/// 
/// This header provides JSON serialization support using nlohmann/json library.
/// Include this header only if you need JSON serialization functionality.
/// 
/// Requirements:
///   - nlohmann/json library (https://github.com/nlohmann/json)
/// 
/// Usage:
///   #include <nlohmann/json.hpp>
///   #include <vrm_avatar_model/json_serialization.hpp>
///   
///   vrm_avatar_model::AvatarModel avatar;
///   nlohmann::json j = avatar;  // to JSON
///   avatar = j.get<vrm_avatar_model::AvatarModel>();  // from JSON

#ifdef VRM_AVATAR_MODEL_USE_JSON

#include "vrm_avatar_model.hpp"
#include <nlohmann/json.hpp>

namespace vrm_avatar_model {

// Helper macros for enum serialization
// Note: Deserialization performs basic range checking where possible, but invalid
// enum values from JSON may still result in undefined behavior. Ensure JSON data
// is validated before deserialization in production code.
#define ENUM_TO_JSON(EnumType) \
    inline void to_json(nlohmann::json& j, const EnumType& e) { \
        j = static_cast<int>(e); \
    } \
    inline void from_json(const nlohmann::json& j, EnumType& e) { \
        e = static_cast<EnumType>(j.get<int>()); \
    }

ENUM_TO_JSON(AllowedUser)
ENUM_TO_JSON(LicenseType)
ENUM_TO_JSON(CommercialUsage)
ENUM_TO_JSON(ViolentUsage)
ENUM_TO_JSON(SexualUsage)
ENUM_TO_JSON(HumanoidBone)
ENUM_TO_JSON(ExpressionPreset)
ENUM_TO_JSON(ExpressionOverrideType)
ENUM_TO_JSON(RenderMode)
ENUM_TO_JSON(CullMode)
ENUM_TO_JSON(OutlineWidthMode)
ENUM_TO_JSON(OutlineColorMode)
ENUM_TO_JSON(Axis)

#undef ENUM_TO_JSON

// AvatarMeta serialization
inline void to_json(nlohmann::json& j, const AvatarMeta& meta) {
    j = nlohmann::json{
        {"title", meta.title},
        {"allowed_user", meta.allowed_user},
        {"license_type", meta.license_type},
        {"commercial_usage", meta.commercial_usage},
        {"violent_usage", meta.violent_usage},
        {"sexual_usage", meta.sexual_usage}
    };
    if (meta.version) j["version"] = *meta.version;
    if (meta.author) j["author"] = *meta.author;
    if (meta.contact_information) j["contact_information"] = *meta.contact_information;
    if (meta.reference) j["reference"] = *meta.reference;
    if (meta.thumbnail) j["thumbnail"] = *meta.thumbnail;
    if (meta.other_license_name) j["other_license_name"] = *meta.other_license_name;
    if (meta.other_license_url) j["other_license_url"] = *meta.other_license_url;
    if (meta.other_permission_info) j["other_permission_info"] = *meta.other_permission_info;
    if (meta.credits) j["credits"] = *meta.credits;
}

inline void from_json(const nlohmann::json& j, AvatarMeta& meta) {
    j.at("title").get_to(meta.title);
    j.at("allowed_user").get_to(meta.allowed_user);
    j.at("license_type").get_to(meta.license_type);
    j.at("commercial_usage").get_to(meta.commercial_usage);
    j.at("violent_usage").get_to(meta.violent_usage);
    j.at("sexual_usage").get_to(meta.sexual_usage);
    
    if (j.contains("version")) meta.version = j["version"].get<std::string>();
    if (j.contains("author")) meta.author = j["author"].get<std::string>();
    if (j.contains("contact_information")) meta.contact_information = j["contact_information"].get<std::string>();
    if (j.contains("reference")) meta.reference = j["reference"].get<std::string>();
    if (j.contains("thumbnail")) meta.thumbnail = j["thumbnail"].get<std::string>();
    if (j.contains("other_license_name")) meta.other_license_name = j["other_license_name"].get<std::string>();
    if (j.contains("other_license_url")) meta.other_license_url = j["other_license_url"].get<std::string>();
    if (j.contains("other_permission_info")) meta.other_permission_info = j["other_permission_info"].get<std::string>();
    if (j.contains("credits")) meta.credits = j["credits"].get<std::string>();
}

// BoneMapping serialization
inline void to_json(nlohmann::json& j, const BoneMapping& bm) {
    j = nlohmann::json{
        {"bone", bm.bone},
        {"node", bm.node}
    };
    if (bm.use_default_values) j["use_default_values"] = *bm.use_default_values;
    if (bm.min) j["min"] = *bm.min;
    if (bm.max) j["max"] = *bm.max;
    if (bm.center) j["center"] = *bm.center;
    if (bm.axis_length) j["axis_length"] = *bm.axis_length;
}

inline void from_json(const nlohmann::json& j, BoneMapping& bm) {
    j.at("bone").get_to(bm.bone);
    j.at("node").get_to(bm.node);
    if (j.contains("use_default_values")) bm.use_default_values = j["use_default_values"].get<bool>();
    if (j.contains("min")) bm.min = j["min"].get<std::array<float, 3>>();
    if (j.contains("max")) bm.max = j["max"].get<std::array<float, 3>>();
    if (j.contains("center")) bm.center = j["center"].get<std::array<float, 3>>();
    if (j.contains("axis_length")) bm.axis_length = j["axis_length"].get<float>();
}

// HumanoidMapping serialization
inline void to_json(nlohmann::json& j, const HumanoidMapping& hm) {
    j = nlohmann::json{
        {"bone_mappings", hm.bone_mappings},
        {"arm_stretch", hm.arm_stretch},
        {"leg_stretch", hm.leg_stretch},
        {"upper_arm_twist", hm.upper_arm_twist},
        {"lower_arm_twist", hm.lower_arm_twist},
        {"upper_leg_twist", hm.upper_leg_twist},
        {"lower_leg_twist", hm.lower_leg_twist},
        {"feet_spacing", hm.feet_spacing},
        {"has_translation_dof", hm.has_translation_dof}
    };
}

inline void from_json(const nlohmann::json& j, HumanoidMapping& hm) {
    j.at("bone_mappings").get_to(hm.bone_mappings);
    if (j.contains("arm_stretch")) hm.arm_stretch = j["arm_stretch"].get<float>();
    if (j.contains("leg_stretch")) hm.leg_stretch = j["leg_stretch"].get<float>();
    if (j.contains("upper_arm_twist")) hm.upper_arm_twist = j["upper_arm_twist"].get<float>();
    if (j.contains("lower_arm_twist")) hm.lower_arm_twist = j["lower_arm_twist"].get<float>();
    if (j.contains("upper_leg_twist")) hm.upper_leg_twist = j["upper_leg_twist"].get<float>();
    if (j.contains("lower_leg_twist")) hm.lower_leg_twist = j["lower_leg_twist"].get<float>();
    if (j.contains("feet_spacing")) hm.feet_spacing = j["feet_spacing"].get<float>();
    if (j.contains("has_translation_dof")) hm.has_translation_dof = j["has_translation_dof"].get<bool>();
}

// MorphTarget serialization
inline void to_json(nlohmann::json& j, const MorphTarget& mt) {
    j = nlohmann::json{
        {"node", mt.node},
        {"index", mt.index},
        {"weight", mt.weight}
    };
}

inline void from_json(const nlohmann::json& j, MorphTarget& mt) {
    j.at("node").get_to(mt.node);
    j.at("index").get_to(mt.index);
    j.at("weight").get_to(mt.weight);
}

// MaterialColorBinding serialization
inline void to_json(nlohmann::json& j, const MaterialColorBinding& mcb) {
    j = nlohmann::json{
        {"material", mcb.material},
        {"property_name", mcb.property_name},
        {"target_value", mcb.target_value}
    };
}

inline void from_json(const nlohmann::json& j, MaterialColorBinding& mcb) {
    j.at("material").get_to(mcb.material);
    j.at("property_name").get_to(mcb.property_name);
    j.at("target_value").get_to(mcb.target_value);
}

// MaterialTextureBinding serialization
inline void to_json(nlohmann::json& j, const MaterialTextureBinding& mtb) {
    j = nlohmann::json{
        {"material", mtb.material},
        {"property_name", mtb.property_name}
    };
    if (mtb.scale) j["scale"] = *mtb.scale;
    if (mtb.offset) j["offset"] = *mtb.offset;
}

inline void from_json(const nlohmann::json& j, MaterialTextureBinding& mtb) {
    j.at("material").get_to(mtb.material);
    j.at("property_name").get_to(mtb.property_name);
    if (j.contains("scale")) mtb.scale = j["scale"].get<std::array<float, 2>>();
    if (j.contains("offset")) mtb.offset = j["offset"].get<std::array<float, 2>>();
}

// Expression serialization
inline void to_json(nlohmann::json& j, const Expression& expr) {
    j = nlohmann::json{
        {"name", expr.name},
        {"preset", expr.preset},
        {"morph_target_bindings", expr.morph_target_bindings},
        {"material_color_bindings", expr.material_color_bindings},
        {"material_texture_bindings", expr.material_texture_bindings},
        {"override_blink", expr.override_blink},
        {"override_look_at", expr.override_look_at},
        {"override_mouth", expr.override_mouth},
        {"is_binary", expr.is_binary}
    };
}

inline void from_json(const nlohmann::json& j, Expression& expr) {
    j.at("name").get_to(expr.name);
    j.at("preset").get_to(expr.preset);
    j.at("morph_target_bindings").get_to(expr.morph_target_bindings);
    j.at("material_color_bindings").get_to(expr.material_color_bindings);
    j.at("material_texture_bindings").get_to(expr.material_texture_bindings);
    j.at("override_blink").get_to(expr.override_blink);
    j.at("override_look_at").get_to(expr.override_look_at);
    j.at("override_mouth").get_to(expr.override_mouth);
    j.at("is_binary").get_to(expr.is_binary);
}

// ExpressionSet serialization
inline void to_json(nlohmann::json& j, const ExpressionSet& es) {
    j = nlohmann::json{{"expressions", es.expressions}};
}

inline void from_json(const nlohmann::json& j, ExpressionSet& es) {
    j.at("expressions").get_to(es.expressions);
}

// MToonMaterial serialization
inline void to_json(nlohmann::json& j, const MToonMaterial& mtoon) {
    j = nlohmann::json{
        {"name", mtoon.name},
        {"render_mode", mtoon.render_mode},
        {"cull_mode", mtoon.cull_mode},
        {"base_color", mtoon.base_color},
        {"cutoff", mtoon.cutoff},
        {"shading_shift", mtoon.shading_shift},
        {"shading_toony", mtoon.shading_toony},
        {"light_color_attenuation", mtoon.light_color_attenuation},
        {"indirect_light_intensity", mtoon.indirect_light_intensity},
        {"rim_lighting_mix", mtoon.rim_lighting_mix},
        {"rim_fresnel_power", mtoon.rim_fresnel_power},
        {"rim_lift", mtoon.rim_lift},
        {"outline_width_mode", mtoon.outline_width_mode},
        {"outline_width", mtoon.outline_width},
        {"outline_color_mode", mtoon.outline_color_mode},
        {"outline_lighting_mix", mtoon.outline_lighting_mix},
        {"normal_scale", mtoon.normal_scale},
        {"uv_animation_rotation", mtoon.uv_animation_rotation}
    };
    
    if (mtoon.render_queue) j["render_queue"] = *mtoon.render_queue;
    if (mtoon.base_texture) j["base_texture"] = *mtoon.base_texture;
    if (mtoon.shade_color) j["shade_color"] = *mtoon.shade_color;
    if (mtoon.shade_texture) j["shade_texture"] = *mtoon.shade_texture;
    if (mtoon.rim_color) j["rim_color"] = *mtoon.rim_color;
    if (mtoon.rim_texture) j["rim_texture"] = *mtoon.rim_texture;
    if (mtoon.outline_color) j["outline_color"] = *mtoon.outline_color;
    if (mtoon.normal_texture) j["normal_texture"] = *mtoon.normal_texture;
    if (mtoon.emissive_color) j["emissive_color"] = *mtoon.emissive_color;
    if (mtoon.emissive_texture) j["emissive_texture"] = *mtoon.emissive_texture;
    if (mtoon.matcap_texture) j["matcap_texture"] = *mtoon.matcap_texture;
    if (mtoon.uv_animation_mask_texture) j["uv_animation_mask_texture"] = *mtoon.uv_animation_mask_texture;
    if (mtoon.uv_animation_scroll) j["uv_animation_scroll"] = *mtoon.uv_animation_scroll;
}

inline void from_json(const nlohmann::json& j, MToonMaterial& mtoon) {
    j.at("name").get_to(mtoon.name);
    j.at("render_mode").get_to(mtoon.render_mode);
    j.at("cull_mode").get_to(mtoon.cull_mode);
    j.at("base_color").get_to(mtoon.base_color);
    
    if (j.contains("render_queue")) mtoon.render_queue = j["render_queue"].get<int>();
    if (j.contains("base_texture")) mtoon.base_texture = j["base_texture"].get<std::string>();
    if (j.contains("shade_color")) mtoon.shade_color = j["shade_color"].get<std::array<float, 3>>();
    if (j.contains("shade_texture")) mtoon.shade_texture = j["shade_texture"].get<std::string>();
    if (j.contains("cutoff")) mtoon.cutoff = j["cutoff"].get<float>();
    if (j.contains("shading_shift")) mtoon.shading_shift = j["shading_shift"].get<float>();
    if (j.contains("shading_toony")) mtoon.shading_toony = j["shading_toony"].get<float>();
    if (j.contains("light_color_attenuation")) mtoon.light_color_attenuation = j["light_color_attenuation"].get<float>();
    if (j.contains("indirect_light_intensity")) mtoon.indirect_light_intensity = j["indirect_light_intensity"].get<float>();
    if (j.contains("rim_color")) mtoon.rim_color = j["rim_color"].get<std::array<float, 3>>();
    if (j.contains("rim_texture")) mtoon.rim_texture = j["rim_texture"].get<std::string>();
    if (j.contains("rim_lighting_mix")) mtoon.rim_lighting_mix = j["rim_lighting_mix"].get<float>();
    if (j.contains("rim_fresnel_power")) mtoon.rim_fresnel_power = j["rim_fresnel_power"].get<float>();
    if (j.contains("rim_lift")) mtoon.rim_lift = j["rim_lift"].get<float>();
    if (j.contains("outline_width_mode")) mtoon.outline_width_mode = j["outline_width_mode"].get<OutlineWidthMode>();
    if (j.contains("outline_width")) mtoon.outline_width = j["outline_width"].get<float>();
    if (j.contains("outline_color")) mtoon.outline_color = j["outline_color"].get<std::array<float, 3>>();
    if (j.contains("outline_color_mode")) mtoon.outline_color_mode = j["outline_color_mode"].get<OutlineColorMode>();
    if (j.contains("outline_lighting_mix")) mtoon.outline_lighting_mix = j["outline_lighting_mix"].get<float>();
    if (j.contains("normal_texture")) mtoon.normal_texture = j["normal_texture"].get<std::string>();
    if (j.contains("normal_scale")) mtoon.normal_scale = j["normal_scale"].get<float>();
    if (j.contains("emissive_color")) mtoon.emissive_color = j["emissive_color"].get<std::array<float, 3>>();
    if (j.contains("emissive_texture")) mtoon.emissive_texture = j["emissive_texture"].get<std::string>();
    if (j.contains("matcap_texture")) mtoon.matcap_texture = j["matcap_texture"].get<std::string>();
    if (j.contains("uv_animation_mask_texture")) mtoon.uv_animation_mask_texture = j["uv_animation_mask_texture"].get<std::string>();
    if (j.contains("uv_animation_scroll")) mtoon.uv_animation_scroll = j["uv_animation_scroll"].get<std::array<float, 2>>();
    if (j.contains("uv_animation_rotation")) mtoon.uv_animation_rotation = j["uv_animation_rotation"].get<float>();
}

// Material serialization
inline void to_json(nlohmann::json& j, const Material& mat) {
    j = nlohmann::json{
        {"name", mat.name},
        {"shader", mat.shader}
    };
    if (mat.mtoon) j["mtoon"] = *mat.mtoon;
}

inline void from_json(const nlohmann::json& j, Material& mat) {
    j.at("name").get_to(mat.name);
    j.at("shader").get_to(mat.shader);
    if (j.contains("mtoon")) mat.mtoon = j["mtoon"].get<MToonMaterial>();
}

// Spring bone serialization helpers
inline void to_json(nlohmann::json& j, const SphereCollider& sc) {
    j = nlohmann::json{
        {"offset", sc.offset},
        {"radius", sc.radius}
    };
    if (sc.node) j["node"] = *sc.node;
}

inline void from_json(const nlohmann::json& j, SphereCollider& sc) {
    j.at("offset").get_to(sc.offset);
    j.at("radius").get_to(sc.radius);
    if (j.contains("node")) sc.node = j["node"].get<std::string>();
}

inline void to_json(nlohmann::json& j, const CapsuleCollider& cc) {
    j = nlohmann::json{
        {"offset_start", cc.offset_start},
        {"offset_end", cc.offset_end},
        {"radius", cc.radius}
    };
    if (cc.node) j["node"] = *cc.node;
}

inline void from_json(const nlohmann::json& j, CapsuleCollider& cc) {
    j.at("offset_start").get_to(cc.offset_start);
    j.at("offset_end").get_to(cc.offset_end);
    j.at("radius").get_to(cc.radius);
    if (j.contains("node")) cc.node = j["node"].get<std::string>();
}

inline void to_json(nlohmann::json& j, const ColliderGroup& cg) {
    j = nlohmann::json{
        {"name", cg.name},
        {"sphere_colliders", cg.sphere_colliders},
        {"capsule_colliders", cg.capsule_colliders}
    };
}

inline void from_json(const nlohmann::json& j, ColliderGroup& cg) {
    j.at("name").get_to(cg.name);
    j.at("sphere_colliders").get_to(cg.sphere_colliders);
    j.at("capsule_colliders").get_to(cg.capsule_colliders);
}

inline void to_json(nlohmann::json& j, const SpringBoneJoint& sbj) {
    j = nlohmann::json{
        {"node", sbj.node},
        {"hit_radius", sbj.hit_radius},
        {"stiffness", sbj.stiffness},
        {"gravity_power", sbj.gravity_power},
        {"gravity_dir", sbj.gravity_dir},
        {"drag_force", sbj.drag_force}
    };
}

inline void from_json(const nlohmann::json& j, SpringBoneJoint& sbj) {
    j.at("node").get_to(sbj.node);
    j.at("hit_radius").get_to(sbj.hit_radius);
    j.at("stiffness").get_to(sbj.stiffness);
    j.at("gravity_power").get_to(sbj.gravity_power);
    j.at("gravity_dir").get_to(sbj.gravity_dir);
    j.at("drag_force").get_to(sbj.drag_force);
}

inline void to_json(nlohmann::json& j, const SpringBoneChain& sbc) {
    j = nlohmann::json{
        {"root_node", sbc.root_node},
        {"joints", sbc.joints},
        {"collider_groups", sbc.collider_groups}
    };
    if (sbc.comment) j["comment"] = *sbc.comment;
    if (sbc.center) j["center"] = *sbc.center;
}

inline void from_json(const nlohmann::json& j, SpringBoneChain& sbc) {
    j.at("root_node").get_to(sbc.root_node);
    j.at("joints").get_to(sbc.joints);
    j.at("collider_groups").get_to(sbc.collider_groups);
    if (j.contains("comment")) sbc.comment = j["comment"].get<std::string>();
    if (j.contains("center")) sbc.center = j["center"].get<std::string>();
}

inline void to_json(nlohmann::json& j, const SpringBoneConfig& sbc) {
    j = nlohmann::json{
        {"collider_groups", sbc.collider_groups},
        {"chains", sbc.chains}
    };
}

inline void from_json(const nlohmann::json& j, SpringBoneConfig& sbc) {
    j.at("collider_groups").get_to(sbc.collider_groups);
    j.at("chains").get_to(sbc.chains);
}

// Constraint serialization
inline void to_json(nlohmann::json& j, const RollConstraint& rc) {
    j = nlohmann::json{
        {"source_node", rc.source_node},
        {"destination_node", rc.destination_node},
        {"roll_axis", rc.roll_axis},
        {"weight", rc.weight}
    };
}

inline void from_json(const nlohmann::json& j, RollConstraint& rc) {
    j.at("source_node").get_to(rc.source_node);
    j.at("destination_node").get_to(rc.destination_node);
    j.at("roll_axis").get_to(rc.roll_axis);
    j.at("weight").get_to(rc.weight);
}

inline void to_json(nlohmann::json& j, const AimConstraint& ac) {
    j = nlohmann::json{
        {"source_node", ac.source_node},
        {"destination_node", ac.destination_node},
        {"aim_axis", ac.aim_axis},
        {"weight", ac.weight}
    };
}

inline void from_json(const nlohmann::json& j, AimConstraint& ac) {
    j.at("source_node").get_to(ac.source_node);
    j.at("destination_node").get_to(ac.destination_node);
    j.at("aim_axis").get_to(ac.aim_axis);
    j.at("weight").get_to(ac.weight);
}

inline void to_json(nlohmann::json& j, const RotationConstraint& rc) {
    j = nlohmann::json{
        {"source_node", rc.source_node},
        {"destination_node", rc.destination_node},
        {"weight", rc.weight}
    };
    if (rc.freeze_axes) j["freeze_axes"] = *rc.freeze_axes;
}

inline void from_json(const nlohmann::json& j, RotationConstraint& rc) {
    j.at("source_node").get_to(rc.source_node);
    j.at("destination_node").get_to(rc.destination_node);
    j.at("weight").get_to(rc.weight);
    if (j.contains("freeze_axes")) rc.freeze_axes = j["freeze_axes"].get<std::array<bool, 3>>();
}

inline void to_json(nlohmann::json& j, const ConstraintSet& cs) {
    j = nlohmann::json{
        {"roll_constraints", cs.roll_constraints},
        {"aim_constraints", cs.aim_constraints},
        {"rotation_constraints", cs.rotation_constraints}
    };
}

inline void from_json(const nlohmann::json& j, ConstraintSet& cs) {
    j.at("roll_constraints").get_to(cs.roll_constraints);
    j.at("aim_constraints").get_to(cs.aim_constraints);
    j.at("rotation_constraints").get_to(cs.rotation_constraints);
}

// AvatarModel serialization
inline void to_json(nlohmann::json& j, const AvatarModel& model) {
    j = nlohmann::json{{"meta", model.meta}};
    
    if (model.humanoid) j["humanoid"] = *model.humanoid;
    if (model.expressions) j["expressions"] = *model.expressions;
    if (model.materials) j["materials"] = *model.materials;
    if (model.spring_bones) j["spring_bones"] = *model.spring_bones;
    if (model.constraints) j["constraints"] = *model.constraints;
    if (model.vrm_version) j["vrm_version"] = *model.vrm_version;
    if (!model.extensions.empty()) j["extensions"] = model.extensions;
}

inline void from_json(const nlohmann::json& j, AvatarModel& model) {
    j.at("meta").get_to(model.meta);
    
    if (j.contains("humanoid")) model.humanoid = j["humanoid"].get<HumanoidMapping>();
    if (j.contains("expressions")) model.expressions = j["expressions"].get<ExpressionSet>();
    if (j.contains("materials")) model.materials = j["materials"].get<std::vector<Material>>();
    if (j.contains("spring_bones")) model.spring_bones = j["spring_bones"].get<SpringBoneConfig>();
    if (j.contains("constraints")) model.constraints = j["constraints"].get<ConstraintSet>();
    if (j.contains("vrm_version")) model.vrm_version = j["vrm_version"].get<std::string>();
    
    if (j.contains("extensions")) {
        model.extensions = j["extensions"].get<ExtensionMap>();
    } else {
        model.extensions.clear();
    }
}

} // namespace vrm_avatar_model

#endif // VRM_AVATAR_MODEL_USE_JSON
