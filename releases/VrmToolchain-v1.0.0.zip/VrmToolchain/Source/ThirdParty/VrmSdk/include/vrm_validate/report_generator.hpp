#pragma once

#include <string>
#include <vrm_validate/vrm_validator.hpp>

namespace vrm {

class ReportGenerator {
public:
    static std::string generate_text_report(const ValidationResult& result);
    // Emits schemaVersion:1, tool{name,version}, files[] and issues with jsonPointer/details
    static std::string generate_json_report(const ValidationResult& result, const GLBFile* glb = nullptr, const std::string& input = "");
    // Serialize full FileReport envelope
    static std::string SerializeReportEnvelope(const VRMValidator::FileReport& report);
    static std::string SerializeReports(const std::vector<VRMValidator::FileReport>& reports, bool pretty = false);
    // Generate JSON error report for CLI errors (usage, file not found, etc.)
    static std::string GenerateErrorReport(const std::string& error_code, const std::string& error_message, const std::string& input = "", bool pretty = false);
};

} // namespace vrm
