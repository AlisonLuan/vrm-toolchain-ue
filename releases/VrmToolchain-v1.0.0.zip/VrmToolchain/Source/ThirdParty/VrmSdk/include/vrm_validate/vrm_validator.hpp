#pragma once

#include <string>
#include <vector>
#include <optional>
#include <vrm_validate/glb_parser.hpp>

namespace vrm {

enum class VRMVersion {
    Unknown,
    VRM0,
    VRM1
};

struct HumanoidBone {
    std::string name;
    std::string node_name;
    bool required;
};

// Issue struct follows Issue Taxonomy: code, severity, message, jsonPointer, details (JSON string)
struct Issue {
    std::string code;             // e.g., E_VRM_MISSING_EXTENSION
    std::string severity;         // info | warn | error
    std::string message;
    std::string jsonPointer;      // JSON Pointer into the glTF if available
    std::string detailsJsonString; // JSON object serialized as string
};

struct VRMMetadata {
    std::string title;
    std::string version;
    std::string author;
    std::string contact_information;
    std::string reference;
    std::string license;
    std::vector<std::string> allowed_user_names;
    std::string violent_usage;
    std::string sexual_usage;
    std::string commercial_usage;
};

struct ValidationResult {
    bool valid;
    VRMVersion vrm_version;
    VRMMetadata metadata;
    
    // Humanoid information
    int humanoid_bone_count;
    std::vector<std::string> humanoid_bones_present;
    std::vector<std::string> humanoid_bones_missing;
    double humanoid_coverage_percentage;
    
    // Features
    bool has_spring_bones;
    int spring_bone_count;
    bool has_materials;
    int material_count;
    bool has_constraints;
    int constraint_count;
    
    // Issues (standardized)
    std::vector<Issue> issues;

    struct Summary {
        std::string status; // "error" | "warn" | "info"
        int errors = 0;
        int warnings = 0;
        int infos = 0;
    } summary;
};

class VRMValidator {
public:
    // Validate given GLB file (file parsed internally when using ValidateFile)
    static ValidationResult validate(const GLBFile& glb);
    struct FileReport {
        ValidationResult result;
        std::string input;
        std::optional<GLBFile> glb;
    };
    static FileReport ValidateFile(const std::string& filepath);

private:
    // JSON is passed as text to avoid public dependency on nlohmann::json
    static VRMVersion detect_version(const std::string& json_text);
    static void validate_vrm0(const std::string& json_text, ValidationResult& result);
    static void validate_vrm1(const std::string& json_text, ValidationResult& result);
    static void extract_metadata(const std::string& json_text, VRMVersion version, VRMMetadata& metadata);
    static void validate_humanoid(const std::string& json_text, VRMVersion version, ValidationResult& result);
    static void check_spring_bones(const std::string& json_text, VRMVersion version, ValidationResult& result);
    static void check_expressions(const std::string& json_text, VRMVersion version, ValidationResult& result);
    static void check_materials(const std::string& json_text, ValidationResult& result);
    static void check_constraints(const std::string& json_text, VRMVersion version, ValidationResult& result);
    static std::vector<std::string> get_required_bones();
    // Compute summary from issues array
    static void compute_summary(ValidationResult& result);
};

} // namespace vrm
