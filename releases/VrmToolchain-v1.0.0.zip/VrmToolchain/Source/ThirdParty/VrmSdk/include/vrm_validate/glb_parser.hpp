#pragma once

#include <string>
#include <vector>
#include <cstdint>
#include <optional>

namespace vrm {

struct GLBHeader {
    uint32_t magic;
    uint32_t version;
    uint32_t length;
};

struct GLBChunk {
    uint32_t length;
    uint32_t type;
    std::vector<uint8_t> data;
};

struct GLBFile {
    GLBHeader header;
    std::vector<GLBChunk> chunks;
    // JSON text of the glTF chunk (kept as plain string to avoid public dependency on nlohmann)
    std::string json_text;
    std::vector<uint8_t> binary_data;
};

class GLBParser {
public:
    // Security limits to prevent memory exhaustion and overflow attacks
    static constexpr std::streamoff MAX_FILE_SIZE = 2LL * 1024 * 1024 * 1024; // 2GB
    static constexpr uint32_t MAX_CHUNK_SIZE = 100 * 1024 * 1024; // 100MB
    
    static std::optional<GLBFile> parse(const std::string& filepath);
    static bool validate_structure(const GLBFile& glb);
    
private:
    static bool read_header(const std::vector<uint8_t>& data, size_t& offset, GLBHeader& header);
    static bool read_chunk(const std::vector<uint8_t>& data, size_t& offset, GLBChunk& chunk);
};

} // namespace vrm
