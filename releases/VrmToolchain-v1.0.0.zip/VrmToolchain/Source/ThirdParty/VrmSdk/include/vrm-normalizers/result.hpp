#pragma once

// Result and error types for VRM normalization

#include <string>
#include <optional>

namespace vrm_normalizers {

// Error codes for normalization
enum class NormalizeError {
    Success = 0,
    InvalidJsonData,
    NoVrmExtensionFound,
    MissingRequiredFields
};

// Result type for normalization
template<typename T>
struct Result {
    NormalizeError error;
    std::string error_message;
    std::optional<T> value;
    
    bool is_ok() const { return error == NormalizeError::Success && value.has_value(); }
    bool is_err() const { return !is_ok(); }
};

}  // namespace vrm_normalizers
