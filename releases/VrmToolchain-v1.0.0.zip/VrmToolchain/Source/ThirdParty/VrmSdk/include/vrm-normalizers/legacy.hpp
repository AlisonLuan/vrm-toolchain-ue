#pragma once

// Legacy typed-struct APIs for backward compatibility.
// Users should prefer the JSON-based API in normalizers.hpp for new code.

#include "vrm-glb-parser/vrm0.hpp"
#include "vrm-glb-parser/vrm1.hpp"
#include "vrm_avatar_model/avatar_model.hpp"
#include <algorithm>
#include <cctype>
#include <string>
#include <type_traits>
#include <utility>

// Compatibility helpers: detect different versions of vrm_avatar_model::Meta and
// humanoid storage and provide generic setters so this file can compile against
// both older (name/authors/contactInformation/humanoidBones) and newer
// (title/author/contact_information/humanoid->bones / license enum) APIs.

namespace vrm_normalizers::detail {

// Issue C fix: Type-safe helpers for optional/string assignment
template <typename T>
struct is_optional : std::false_type {};
template <typename U>
struct is_optional<std::optional<U>> : std::true_type {};
template <typename T>
inline constexpr bool is_optional_v = is_optional<std::remove_cvref_t<T>>::value;

// Type-safe string assignment that handles optional<string> <-> string conversions
template <typename Dest, typename Src>
void assign_string(Dest& dest, const Src& src) {
    if constexpr (is_optional_v<Dest>) {
        if constexpr (is_optional_v<Src>) {
            dest = src;
        } else {
            if (!src.empty()) {
                dest = src;
            } else {
                dest.reset();
            }
        }
    } else {
        if constexpr (is_optional_v<Src>) {
            dest = src ? *src : std::string{};
        } else {
            dest = src;
        }
    }
}

// Member detection helpers
template <typename T, typename = void>
struct has_member_name : std::false_type {};
template <typename T>
struct has_member_name<T, std::void_t<decltype(std::declval<T>().name)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_title : std::false_type {};
template <typename T>
struct has_member_title<T, std::void_t<decltype(std::declval<T>().title)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_authors : std::false_type {};
template <typename T>
struct has_member_authors<T, std::void_t<decltype(std::declval<T>().authors)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_author : std::false_type {};
template <typename T>
struct has_member_author<T, std::void_t<decltype(std::declval<T>().author)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_contactInformation : std::false_type {};
template <typename T>
struct has_member_contactInformation<T, std::void_t<decltype(std::declval<T>().contactInformation)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_contact_information : std::false_type {};
template <typename T>
struct has_member_contact_information<T, std::void_t<decltype(std::declval<T>().contact_information)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_credits : std::false_type {};
template <typename T>
struct has_member_credits<T, std::void_t<decltype(std::declval<T>().credits)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_copyright_information : std::false_type {};
template <typename T>
struct has_member_copyright_information<T, std::void_t<decltype(std::declval<T>().copyright_information)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_reference : std::false_type {};
template <typename T>
struct has_member_reference<T, std::void_t<decltype(std::declval<T>().reference)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_references : std::false_type {};
template <typename T>
struct has_member_references<T, std::void_t<decltype(std::declval<T>().references)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_license_name : std::false_type {};
template <typename T>
struct has_member_license_name<T, std::void_t<decltype(std::declval<T>().license.name)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_license_type : std::false_type {};
template <typename T>
struct has_member_license_type<T, std::void_t<decltype(std::declval<T>().license_type)>> : std::true_type {};

// Humanoid bones storage detection
template <typename T, typename = void>
struct has_member_humanoidBones : std::false_type {};
template <typename T>
struct has_member_humanoidBones<T, std::void_t<decltype(std::declval<T>().humanoidBones)>> : std::true_type {};

// Issue B fix: Stricter traits that validate the actual API shape, not just existence
// Verify humanoidBones supports string indexing (operator[](std::string))
template <typename T, typename = void>
struct has_humanoidBones_string_index : std::false_type {};
template <typename T>
struct has_humanoidBones_string_index<T, std::void_t<
    decltype(std::declval<T&>().humanoidBones[std::declval<std::string>()])
>> : std::true_type {};

// Verify bone_mappings is iterable and has proper structure
template <typename T, typename = void>
struct has_bone_mappings_iterable : std::false_type {};
template <typename T>
struct has_bone_mappings_iterable<T, std::void_t<
    decltype(std::begin(std::declval<T&>().bone_mappings)),
    decltype(std::declval<T&>().bone_mappings[0].bone),
    decltype(std::declval<T&>().bone_mappings[0].node)
>> : std::true_type {};

template <typename T, typename = void>
struct has_member_humanoid : std::false_type {};
template <typename T>
struct has_member_humanoid<T, std::void_t<decltype(std::declval<T>().humanoid)>> : std::true_type {};

template <typename T, typename = void>
struct has_member_bones : std::false_type {};
template <typename T>
struct has_member_bones<T, std::void_t<decltype(std::declval<T>().bones)>> : std::true_type {};

// Detect bones inside a container-like member's value_type (e.g., std::optional<Humanoid>)
template <typename T, typename = void>
struct has_member_bones_value_type : std::false_type {};
template <typename T>
struct has_member_bones_value_type<T, std::void_t<decltype(std::declval<typename T::value_type>().bones)>> : std::true_type {};

// Detect bone_mappings vector-style newer layout (e.g., humanoid.bone_mappings)
template <typename T, typename = void>
struct has_member_bone_mappings : std::false_type {};
template <typename T>
struct has_member_bone_mappings<T, std::void_t<decltype(std::declval<T>().bone_mappings)>> : std::true_type {};

// Detect bone_mappings in an optional-like humanoid member's value_type
template <typename T, typename = void>
struct has_member_bone_mappings_value_type : std::false_type {};
template <typename T>
struct has_member_bone_mappings_value_type<T, std::void_t<decltype(std::declval<typename T::value_type>().bone_mappings)>> : std::true_type {};

// Element type helpers for bone_mappings
template <typename T, typename = void>
struct has_elem_member_bone : std::false_type {};
template <typename T>
struct has_elem_member_bone<T, std::void_t<decltype(std::declval<T>().bone)>> : std::true_type {};

template <typename T, typename = void>
struct has_elem_member_node : std::false_type {};
template <typename T>
struct has_elem_member_node<T, std::void_t<decltype(std::declval<T>().node)>> : std::true_type {};

template <typename T, typename = void>
struct has_elem_pair_first_second : std::false_type {};
template <typename T>
struct has_elem_pair_first_second<T, std::void_t<decltype(std::declval<T>().first), decltype(std::declval<T>().second)>> : std::true_type {};

// Detect an enum type for humanoid bones (vrm_avatar_model::HumanoidBone)
template <typename = void>
struct has_humanoid_bone_enum : std::false_type {};
template <>
struct has_humanoid_bone_enum<std::void_t<decltype(vrm_avatar_model::HumanoidBone::Hips)>> : std::true_type {};

// Per-enumerator presence checks (SFINAE) to avoid referencing enumerators that don't exist
template <typename = void>
struct has_enum_Hips : std::false_type {};
template <>
struct has_enum_Hips<std::void_t<decltype(vrm_avatar_model::HumanoidBone::Hips)>> : std::true_type {};

template <typename = void>
struct has_enum_Spine : std::false_type {};
template <>
struct has_enum_Spine<std::void_t<decltype(vrm_avatar_model::HumanoidBone::Spine)>> : std::true_type {};

template <typename = void>
struct has_enum_Chest : std::false_type {};
template <>
struct has_enum_Chest<std::void_t<decltype(vrm_avatar_model::HumanoidBone::Chest)>> : std::true_type {};

template <typename = void>
struct has_enum_UpperChest : std::false_type {};
template <>
struct has_enum_UpperChest<std::void_t<decltype(vrm_avatar_model::HumanoidBone::UpperChest)>> : std::true_type {};

template <typename = void>
struct has_enum_Neck : std::false_type {};
template <>
struct has_enum_Neck<std::void_t<decltype(vrm_avatar_model::HumanoidBone::Neck)>> : std::true_type {};

template <typename = void>
struct has_enum_Head : std::false_type {};
template <>
struct has_enum_Head<std::void_t<decltype(vrm_avatar_model::HumanoidBone::Head)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftEye : std::false_type {};
template <>
struct has_enum_LeftEye<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftEye)>> : std::true_type {};

template <typename = void>
struct has_enum_RightEye : std::false_type {};
template <>
struct has_enum_RightEye<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightEye)>> : std::true_type {};

template <typename = void>
struct has_enum_Jaw : std::false_type {};
template <>
struct has_enum_Jaw<std::void_t<decltype(vrm_avatar_model::HumanoidBone::Jaw)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftUpperLeg : std::false_type {};
template <>
struct has_enum_LeftUpperLeg<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftUpperLeg)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftLowerLeg : std::false_type {};
template <>
struct has_enum_LeftLowerLeg<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftLowerLeg)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftFoot : std::false_type {};
template <>
struct has_enum_LeftFoot<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftFoot)>> : std::true_type {};

template <typename = void>
struct has_enum_RightUpperLeg : std::false_type {};
template <>
struct has_enum_RightUpperLeg<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightUpperLeg)>> : std::true_type {};

template <typename = void>
struct has_enum_RightLowerLeg : std::false_type {};
template <>
struct has_enum_RightLowerLeg<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightLowerLeg)>> : std::true_type {};

template <typename = void>
struct has_enum_RightFoot : std::false_type {};
template <>
struct has_enum_RightFoot<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightFoot)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftUpperArm : std::false_type {};
template <>
struct has_enum_LeftUpperArm<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftUpperArm)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftLowerArm : std::false_type {};
template <>
struct has_enum_LeftLowerArm<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftLowerArm)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftHand : std::false_type {};
template <>
struct has_enum_LeftHand<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftHand)>> : std::true_type {};

template <typename = void>
struct has_enum_RightUpperArm : std::false_type {};
template <>
struct has_enum_RightUpperArm<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightUpperArm)>> : std::true_type {};

template <typename = void>
struct has_enum_RightLowerArm : std::false_type {};
template <>
struct has_enum_RightLowerArm<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightLowerArm)>> : std::true_type {};

template <typename = void>
struct has_enum_RightHand : std::false_type {};
template <>
struct has_enum_RightHand<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightHand)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftThumbProximal : std::false_type {};
template <>
struct has_enum_LeftThumbProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftThumbProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftThumbIntermediate : std::false_type {};
template <>
struct has_enum_LeftThumbIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftThumbIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftThumbDistal : std::false_type {};
template <>
struct has_enum_LeftThumbDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftThumbDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftIndexProximal : std::false_type {};
template <>
struct has_enum_LeftIndexProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftIndexProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftIndexIntermediate : std::false_type {};
template <>
struct has_enum_LeftIndexIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftIndexIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftIndexDistal : std::false_type {};
template <>
struct has_enum_LeftIndexDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftIndexDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftMiddleProximal : std::false_type {};
template <>
struct has_enum_LeftMiddleProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftMiddleProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftMiddleIntermediate : std::false_type {};
template <>
struct has_enum_LeftMiddleIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftMiddleIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftMiddleDistal : std::false_type {};
template <>
struct has_enum_LeftMiddleDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftMiddleDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftRingProximal : std::false_type {};
template <>
struct has_enum_LeftRingProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftRingProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftRingIntermediate : std::false_type {};
template <>
struct has_enum_LeftRingIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftRingIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftRingDistal : std::false_type {};
template <>
struct has_enum_LeftRingDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftRingDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftLittleProximal : std::false_type {};
template <>
struct has_enum_LeftLittleProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftLittleProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftLittleIntermediate : std::false_type {};
template <>
struct has_enum_LeftLittleIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftLittleIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_LeftLittleDistal : std::false_type {};
template <>
struct has_enum_LeftLittleDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::LeftLittleDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightThumbProximal : std::false_type {};
template <>
struct has_enum_RightThumbProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightThumbProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightThumbIntermediate : std::false_type {};
template <>
struct has_enum_RightThumbIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightThumbIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_RightThumbDistal : std::false_type {};
template <>
struct has_enum_RightThumbDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightThumbDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightIndexProximal : std::false_type {};
template <>
struct has_enum_RightIndexProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightIndexProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightIndexIntermediate : std::false_type {};
template <>
struct has_enum_RightIndexIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightIndexIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_RightIndexDistal : std::false_type {};
template <>
struct has_enum_RightIndexDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightIndexDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightMiddleProximal : std::false_type {};
template <>
struct has_enum_RightMiddleProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightMiddleProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightMiddleIntermediate : std::false_type {};
template <>
struct has_enum_RightMiddleIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightMiddleIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_RightMiddleDistal : std::false_type {};
template <>
struct has_enum_RightMiddleDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightMiddleDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightRingProximal : std::false_type {};
template <>
struct has_enum_RightRingProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightRingProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightRingIntermediate : std::false_type {};
template <>
struct has_enum_RightRingIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightRingIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_RightRingDistal : std::false_type {};
template <>
struct has_enum_RightRingDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightRingDistal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightLittleProximal : std::false_type {};
template <>
struct has_enum_RightLittleProximal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightLittleProximal)>> : std::true_type {};

template <typename = void>
struct has_enum_RightLittleIntermediate : std::false_type {};
template <>
struct has_enum_RightLittleIntermediate<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightLittleIntermediate)>> : std::true_type {};

template <typename = void>
struct has_enum_RightLittleDistal : std::false_type {};
template <>
struct has_enum_RightLittleDistal<std::void_t<decltype(vrm_avatar_model::HumanoidBone::RightLittleDistal)>> : std::true_type {};

// Map string bone names to the vrm_avatar_model::HumanoidBone enum values (if available)
inline std::optional<decltype(vrm_avatar_model::HumanoidBone::Hips)> map_bone_name_to_enum(const std::string& name) {
    if constexpr (has_humanoid_bone_enum<>::value) {
        using E = decltype(vrm_avatar_model::HumanoidBone::Hips);
        if (name == "hips" && has_enum_Hips<>::value) return E::Hips;
        if (name == "spine" && has_enum_Spine<>::value) return E::Spine;
        if (name == "chest" && has_enum_Chest<>::value) return E::Chest;
        if (name == "upperchest" && has_enum_UpperChest<>::value) return E::UpperChest;
        if (name == "neck" && has_enum_Neck<>::value) return E::Neck;
        if (name == "head" && has_enum_Head<>::value) return E::Head;
        if (name == "lefteye" && has_enum_LeftEye<>::value) return E::LeftEye;
        if (name == "righteye" && has_enum_RightEye<>::value) return E::RightEye;
        if (name == "jaw" && has_enum_Jaw<>::value) return E::Jaw;
        if (name == "leftupperleg" && has_enum_LeftUpperLeg<>::value) return E::LeftUpperLeg;
        if (name == "leftlowerleg" && has_enum_LeftLowerLeg<>::value) return E::LeftLowerLeg;
        if (name == "leftfoot" && has_enum_LeftFoot<>::value) return E::LeftFoot;
        if (name == "rightupperleg" && has_enum_RightUpperLeg<>::value) return E::RightUpperLeg;
        if (name == "rightlowerleg" && has_enum_RightLowerLeg<>::value) return E::RightLowerLeg;
        if (name == "rightfoot" && has_enum_RightFoot<>::value) return E::RightFoot;
        if (name == "leftupperarm" && has_enum_LeftUpperArm<>::value) return E::LeftUpperArm;
        if (name == "leftlowerarm" && has_enum_LeftLowerArm<>::value) return E::LeftLowerArm;
        if (name == "lefthand" && has_enum_LeftHand<>::value) return E::LeftHand;
        if (name == "rightupperarm" && has_enum_RightUpperArm<>::value) return E::RightUpperArm;
        if (name == "rightlowerarm" && has_enum_RightLowerArm<>::value) return E::RightLowerArm;
        if (name == "righthand" && has_enum_RightHand<>::value) return E::RightHand;
        
        if (name == "leftthumbproximal" && has_enum_LeftThumbProximal<>::value) return E::LeftThumbProximal;
        if (name == "leftthumbintermediate" && has_enum_LeftThumbIntermediate<>::value) return E::LeftThumbIntermediate;
        if (name == "leftthumbdistal" && has_enum_LeftThumbDistal<>::value) return E::LeftThumbDistal;
        if (name == "leftindexproximal" && has_enum_LeftIndexProximal<>::value) return E::LeftIndexProximal;
        if (name == "leftindexintermediate" && has_enum_LeftIndexIntermediate<>::value) return E::LeftIndexIntermediate;
        if (name == "leftindexdistal" && has_enum_LeftIndexDistal<>::value) return E::LeftIndexDistal;
        if (name == "leftmiddleproximal" && has_enum_LeftMiddleProximal<>::value) return E::LeftMiddleProximal;
        if (name == "leftmiddleintermediate" && has_enum_LeftMiddleIntermediate<>::value) return E::LeftMiddleIntermediate;
        if (name == "leftmiddledistal" && has_enum_LeftMiddleDistal<>::value) return E::LeftMiddleDistal;
        if (name == "leftringproximal" && has_enum_LeftRingProximal<>::value) return E::LeftRingProximal;
        if (name == "leftringintermediate" && has_enum_LeftRingIntermediate<>::value) return E::LeftRingIntermediate;
        if (name == "leftringdistal" && has_enum_LeftRingDistal<>::value) return E::LeftRingDistal;
        if (name == "leftlittleproximal" && has_enum_LeftLittleProximal<>::value) return E::LeftLittleProximal;
        if (name == "leftlittleintermediate" && has_enum_LeftLittleIntermediate<>::value) return E::LeftLittleIntermediate;
        if (name == "leftlittledistal" && has_enum_LeftLittleDistal<>::value) return E::LeftLittleDistal;

        if (name == "rightthumbproximal" && has_enum_RightThumbProximal<>::value) return E::RightThumbProximal;
        if (name == "rightthumbintermediate" && has_enum_RightThumbIntermediate<>::value) return E::RightThumbIntermediate;
        if (name == "rightthumbdistal" && has_enum_RightThumbDistal<>::value) return E::RightThumbDistal;
        if (name == "rightindexproximal" && has_enum_RightIndexProximal<>::value) return E::RightIndexProximal;
        if (name == "rightindexintermediate" && has_enum_RightIndexIntermediate<>::value) return E::RightIndexIntermediate;
        if (name == "rightindexdistal" && has_enum_RightIndexDistal<>::value) return E::RightIndexDistal;
        if (name == "rightmiddleproximal" && has_enum_RightMiddleProximal<>::value) return E::RightMiddleProximal;
        if (name == "rightmiddleintermediate" && has_enum_RightMiddleIntermediate<>::value) return E::RightMiddleIntermediate;
        if (name == "rightmiddledistal" && has_enum_RightMiddleDistal<>::value) return E::RightMiddleDistal;
        if (name == "rightringproximal" && has_enum_RightRingProximal<>::value) return E::RightRingProximal;
        if (name == "rightringintermediate" && has_enum_RightRingIntermediate<>::value) return E::RightRingIntermediate;
        if (name == "rightringdistal" && has_enum_RightRingDistal<>::value) return E::RightRingDistal;
        if (name == "rightlittleproximal" && has_enum_RightLittleProximal<>::value) return E::RightLittleProximal;
        if (name == "rightlittleintermediate" && has_enum_RightLittleIntermediate<>::value) return E::RightLittleIntermediate;
        if (name == "rightlittledistal" && has_enum_RightLittleDistal<>::value) return E::RightLittleDistal;

        // For fine-grained finger enums, many builds may not have them — skip if not present
        return std::nullopt;
    } else {
        return std::nullopt;
    }
}

// Generic copy helper for fields that may be optional<string> or string
template <typename D, typename S>
void copy_field(D& dest, const S& src) {
    if constexpr (std::is_same_v<D, std::string>) {
        if constexpr (std::is_same_v<S, std::optional<std::string>>) dest = src.value_or(std::string{});
        else if constexpr (std::is_assignable_v<D, S>) dest = src;
    } else if constexpr (std::is_same_v<D, std::optional<std::string>>) {
        if constexpr (std::is_same_v<S, std::string>) dest = src;
        else if constexpr (std::is_same_v<S, std::optional<std::string>>) dest = src;
        else if constexpr (std::is_assignable_v<D, S>) dest = src;
    } else if constexpr (std::is_assignable_v<D, S>) {
        dest = src;
    } else {
        // not assignable, do nothing
    }
}

// Assign meta name/title/authors/contact in a version-agnostic way
template <typename DestMeta, typename SrcMeta>
void assign_meta_identifier(DestMeta& dest, const SrcMeta& src) {
    if constexpr (has_member_title<DestMeta>::value) {
        if constexpr (has_member_title<SrcMeta>::value) assign_string(dest.title, src.title);
        else if constexpr (has_member_name<SrcMeta>::value) assign_string(dest.title, src.name);
        else if constexpr (has_member_author<SrcMeta>::value) assign_string(dest.title, src.author);
    } else if constexpr (has_member_name<DestMeta>::value) {
        if constexpr (has_member_name<SrcMeta>::value) assign_string(dest.name, src.name);
        else if constexpr (has_member_title<SrcMeta>::value) assign_string(dest.name, src.title);
        else if constexpr (has_member_author<SrcMeta>::value) assign_string(dest.name, src.author);
    }
}

template <typename DestMeta, typename SrcMeta>
void assign_meta_authors(DestMeta& dest, const SrcMeta& src) {
    if constexpr (has_member_authors<DestMeta>::value) {
        if constexpr (has_member_authors<SrcMeta>::value) {
            dest.authors = src.authors;
        } else if constexpr (has_member_author<SrcMeta>::value) {
            if (!src.author.empty()) {
                dest.authors = std::vector<std::string>{src.author};
            }
        } else if constexpr (has_member_name<SrcMeta>::value) {
            if (!src.name.empty()) {
                dest.authors = std::vector<std::string>{src.name};
            }
        }
    } else if constexpr (has_member_author<DestMeta>::value) {
        if constexpr (has_member_author<SrcMeta>::value) {
            assign_string(dest.author, src.author);
        } else if constexpr (has_member_authors<SrcMeta>::value) {
            if (!src.authors.empty()) {
                // Combine multiple authors with comma separator for single author field
                std::string combined;
                for (size_t i = 0; i < src.authors.size(); ++i) {
                    if (i > 0) combined += ", ";
                    combined += src.authors[i];
                }
                if (!combined.empty()) {
                    assign_string(dest.author, combined);
                }
            }
        } else if constexpr (has_member_name<SrcMeta>::value) {
            assign_string(dest.author, src.name);
        }
    }
}

template <typename DestMeta, typename SrcMeta>
void assign_meta_contact(DestMeta& dest, const SrcMeta& src) {
    if constexpr (has_member_contactInformation<DestMeta>::value) {
        if constexpr (has_member_contactInformation<SrcMeta>::value) {
            assign_string(dest.contactInformation, src.contactInformation);
        } else if constexpr (has_member_contact_information<SrcMeta>::value) {
            assign_string(dest.contactInformation, src.contact_information);
        }
    } else if constexpr (has_member_contact_information<DestMeta>::value) {
        if constexpr (has_member_contact_information<SrcMeta>::value) {
            assign_string(dest.contact_information, src.contact_information);
        } else if constexpr (has_member_contactInformation<SrcMeta>::value) {
            assign_string(dest.contact_information, src.contactInformation);
        }
    }
}

// Assign references if present in destination
template <typename DestMeta, typename SrcMeta>
void assign_meta_references(DestMeta& dest, const SrcMeta& src) {
    if constexpr (has_member_references<DestMeta>::value) {
        if constexpr (has_member_references<SrcMeta>::value) {
            dest.references = src.references;
        } else if constexpr (has_member_reference<SrcMeta>::value) {
            if (!src.reference.empty()) {
                dest.references = std::vector<std::string>{src.reference};
            }
        }
    } else if constexpr (has_member_reference<DestMeta>::value) {
        if constexpr (has_member_reference<SrcMeta>::value) {
            assign_string(dest.reference, src.reference);
        } else if constexpr (has_member_references<SrcMeta>::value) {
            if (!src.references.empty()) {
                assign_string(dest.reference, src.references.front());
            }
        }
    }
}

// Assign license fields in a safe, SFINAE-friendly way
template <typename DestMeta, typename SrcMeta>
void assign_meta_license(DestMeta& dest, const SrcMeta& src) {
    if constexpr (vrm_normalizers::detail::has_member_license_name<DestMeta>::value) {
        // Prefer explicit source fields when available (Legacy struct)
        if constexpr (requires { src.licenseUrl; }) dest.license.url = src.licenseUrl;
        if constexpr (requires { src.otherLicenseUrl; } ) dest.license.url = src.otherLicenseUrl;
        if constexpr (requires { src.otherPermissionUrl; }) dest.license.url = src.otherPermissionUrl;
        if constexpr (requires { src.allowedUserName; }) dest.license.avatarPermission = src.allowedUserName;
        if constexpr (requires { src.commercialUsage; }) dest.license.allowCommercialUsage = (src.commercialUsage != "personalNonProfit");
        if constexpr (requires { src.allowExcessivelyViolentUsage; }) dest.license.allowViolentUsage = src.allowExcessivelyViolentUsage;
        if constexpr (requires { src.allowExcessivelySexualUsage; }) dest.license.allowSexualUsage = src.allowExcessivelySexualUsage;
        if constexpr (requires { src.allowPoliticalOrReligiousUsage; }) dest.license.allowPoliticalOrReligiousUsage = src.allowPoliticalOrReligiousUsage;
        if constexpr (requires { src.allowRedistribution; }) dest.license.allowRedistribution = src.allowRedistribution;
        if constexpr (requires { src.modification; }) dest.license.allowModification = (src.modification != "prohibited");
        if constexpr (requires { src.creditNotation; }) dest.license.creditNotation = src.creditNotation;

        // VRM0 specific: infer from licenseName field if present
        if constexpr (requires { src.licenseName; }) {
            if (src.licenseName) {
                const std::string& license = *src.licenseName;
                if (license == "Redistribution_Prohibited") {
                    dest.license.allowRedistribution = false;
                    dest.license.allowModification = false;
                } else if (license == "CC0") {
                    dest.license.allowRedistribution = true;
                    dest.license.allowModification = true;
                } else if (license.find("CC_BY") != std::string::npos) {
                    dest.license.allowRedistribution = true;
                    dest.license.allowModification = (license.find("_ND") == std::string::npos);
                }
            }
        }
    } else if constexpr (vrm_normalizers::detail::has_member_license_type<DestMeta>::value) {
        // New flat layout (v1.0.1+)
        if constexpr (requires { src.licenseUrl; }) dest.other_license_url = src.licenseUrl;
        if constexpr (requires { src.otherLicenseUrl; } ) dest.other_license_url = src.otherLicenseUrl;
        if constexpr (requires { src.otherPermissionUrl; }) dest.other_permission_info = src.otherPermissionUrl;

        if constexpr (requires { src.allowedUserName; }) {
           if (src.allowedUserName == "Everyone") dest.allowed_user = vrm_avatar_model::AllowedUser::Everyone;
           else if (src.allowedUserName == "OnlyAuthor") dest.allowed_user = vrm_avatar_model::AllowedUser::OnlyAuthor;
        }
        if constexpr (requires { src.avatarPermission; }) {
           if (src.avatarPermission == "everyone") dest.allowed_user = vrm_avatar_model::AllowedUser::Everyone;
           else if (src.avatarPermission == "onlyAuthor") dest.allowed_user = vrm_avatar_model::AllowedUser::OnlyAuthor;
        }

        if constexpr (requires { src.commercialUsage; }) {
            dest.commercial_usage = (src.commercialUsage == "personalNonProfit") ? vrm_avatar_model::CommercialUsage::Disallow : vrm_avatar_model::CommercialUsage::Allow;
        }
        if constexpr (requires { src.commercialUssageName; }) {
           if (src.commercialUssageName == "Allow") dest.commercial_usage = vrm_avatar_model::CommercialUsage::Allow;
           else if (src.commercialUssageName == "Disallow") dest.commercial_usage = vrm_avatar_model::CommercialUsage::Disallow;
        }
        if constexpr (requires { src.allowExcessivelyViolentUsage; }) {
            dest.violent_usage = (src.allowExcessivelyViolentUsage && *src.allowExcessivelyViolentUsage) ? vrm_avatar_model::ViolentUsage::Allow : vrm_avatar_model::ViolentUsage::Disallow;
        }
        if constexpr (requires { src.violentUssageName; }) {
           if (src.violentUssageName == "Allow") dest.violent_usage = vrm_avatar_model::ViolentUsage::Allow;
           else if (src.violentUssageName == "Disallow") dest.violent_usage = vrm_avatar_model::ViolentUsage::Disallow;
        }
        if constexpr (requires { src.allowExcessivelySexualUsage; }) {
            dest.sexual_usage = (src.allowExcessivelySexualUsage && *src.allowExcessivelySexualUsage) ? vrm_avatar_model::SexualUsage::Allow : vrm_avatar_model::SexualUsage::Disallow;
        }
        if constexpr (requires { src.sexualUssageName; }) {
           if (src.sexualUssageName == "Allow") dest.sexual_usage = vrm_avatar_model::SexualUsage::Allow;
           else if (src.sexualUssageName == "Disallow") dest.sexual_usage = vrm_avatar_model::SexualUsage::Disallow;
        }
        if constexpr (requires { src.creditNotation; }) {
            if (src.creditNotation && !src.creditNotation->empty()) {
                if (dest.credits && !dest.credits->empty()) {
                    *dest.credits += " - Credit: " + *src.creditNotation;
                } else {
                    dest.credits = src.creditNotation;
                }
            }
        }

        if constexpr (requires { src.licenseName; }) {
            if (src.licenseName) {
                const std::string& l = *src.licenseName;
                if (l == "CC0") dest.license_type = vrm_avatar_model::LicenseType::CC0;
                else if (l == "CC_BY") dest.license_type = vrm_avatar_model::LicenseType::CC_BY;
                else if (l == "Redistribution_Prohibited") dest.license_type = vrm_avatar_model::LicenseType::Redistribution_Prohibited;
            }
        }
    }
}

// SFINAE helper to set copyright/credits only when available
template <typename DestMeta, typename SrcMeta>
void set_copyright_information(DestMeta& dest, const SrcMeta& src) {
    if constexpr (has_member_copyright_information<DestMeta>::value) {
        dest.copyright_information = src.copyrightInformation;
    } else if constexpr (has_member_credits<DestMeta>::value) {
        dest.credits = src.copyrightInformation;
    }
}

// Helper to get a reference to the bones storage (humanoidBones or humanoid.bones)
// Note: newer versions may use a vector-based `bone_mappings` inside `humanoid`.
template <typename AvatarModel>
auto bones_ref(AvatarModel& m) -> decltype(auto) {
    if constexpr (has_member_humanoidBones<AvatarModel>::value) {
        return (m.humanoidBones);
    } else if constexpr (has_member_humanoid<AvatarModel>::value && (has_member_bones<decltype(m.humanoid)>::value || has_member_bones_value_type<decltype(m.humanoid)>::value)) {
        // Two patterns: humanoid may be an object with .bones, or an optional-like type with value_type::bones
        if constexpr (has_member_bones<decltype(m.humanoid)>::value) {
            return (m.humanoid.bones);
        } else {
            // Ensure a value exists if humanoid is optional
            if (!m.humanoid) m.humanoid = typename decltype(m.humanoid)::value_type{};
            return (m.humanoid->bones);
        }
    } else {
        static_assert(has_member_humanoidBones<AvatarModel>::value || has_member_humanoid<AvatarModel>::value, "Unsupported AvatarModel humanoid storage");
    }
}

// Unified add_bone helper: sets named bones into either the old struct layout
// (humanoidBones) or into the newer vector-based bone_mappings inside humanoid.
template <typename AvatarModel>
void add_bone(AvatarModel& m, const std::string& boneName, int node) {
    if constexpr (has_member_humanoidBones<AvatarModel>::value) {
        auto& bones = m.humanoidBones;
        if (boneName == "hips") bones.hips = node;
        else if (boneName == "spine") bones.spine = node;
        else if (boneName == "chest") bones.chest = node;
        else if (boneName == "upperchest") bones.upperChest = node;
        else if (boneName == "neck") bones.neck = node;
        else if (boneName == "head") bones.head = node;

        else if (boneName == "lefteye") bones.leftEye = node;
        else if (boneName == "righteye") bones.rightEye = node;
        else if (boneName == "jaw") bones.jaw = node;

        else if (boneName == "leftupperleg") bones.leftUpperLeg = node;
        else if (boneName == "leftlowerleg") bones.leftLowerLeg = node;
        else if (boneName == "leftfoot") bones.leftFoot = node;
        else if (boneName == "lefttoes") bones.leftToes = node;

        else if (boneName == "rightupperleg") bones.rightUpperLeg = node;
        else if (boneName == "rightlowerleg") bones.rightLowerLeg = node;
        else if (boneName == "rightfoot") bones.rightFoot = node;
        else if (boneName == "righttoes") bones.rightToes = node;

        else if (boneName == "leftupperarm") bones.leftUpperArm = node;
        else if (boneName == "leftlowerarm") bones.leftLowerArm = node;
        else if (boneName == "lefthand") bones.leftHand = node;

        else if (boneName == "rightupperarm") bones.rightUpperArm = node;
        else if (boneName == "rightlowerarm") bones.rightLowerArm = node;
        else if (boneName == "righthand") bones.rightHand = node;

        // Fingers
        else if (boneName == "leftthumbmetacarpal") bones.leftThumbMetacarpal = node;
        else if (boneName == "leftthumbproximal") bones.leftThumbProximal = node;
        else if (boneName == "leftthumbintermediate") bones.leftThumbIntermediate = node;
        else if (boneName == "leftthumbdistal") bones.leftThumbDistal = node;
        else if (boneName == "leftindexproximal") bones.leftIndexProximal = node;
        else if (boneName == "leftindexintermediate") bones.leftIndexIntermediate = node;
        else if (boneName == "leftindexdistal") bones.leftIndexDistal = node;
        else if (boneName == "leftmiddleproximal") bones.leftMiddleProximal = node;
        else if (boneName == "leftmiddleintermediate") bones.leftMiddleIntermediate = node;
        else if (boneName == "leftmiddledistal") bones.leftMiddleDistal = node;
        else if (boneName == "leftringproximal") bones.leftRingProximal = node;
        else if (boneName == "leftringintermediate") bones.leftRingIntermediate = node;
        else if (boneName == "leftringdistal") bones.leftRingDistal = node;
        else if (boneName == "leftlittleproximal") bones.leftLittleProximal = node;
        else if (boneName == "leftlittleintermediate") bones.leftLittleIntermediate = node;
        else if (boneName == "leftlittledistal") bones.leftLittleDistal = node;

        else if (boneName == "rightthumbmetacarpal") bones.rightThumbMetacarpal = node;
        else if (boneName == "rightthumbproximal") bones.rightThumbProximal = node;
        else if (boneName == "rightthumbintermediate") bones.rightThumbIntermediate = node;
        else if (boneName == "rightthumbdistal") bones.rightThumbDistal = node;
        else if (boneName == "rightindexproximal") bones.rightIndexProximal = node;
        else if (boneName == "rightindexintermediate") bones.rightIndexIntermediate = node;
        else if (boneName == "rightindexdistal") bones.rightIndexDistal = node;
        else if (boneName == "rightmiddleproximal") bones.rightMiddleProximal = node;
        else if (boneName == "rightmiddleintermediate") bones.rightMiddleIntermediate = node;
        else if (boneName == "rightmiddledistal") bones.rightMiddleDistal = node;
        else if (boneName == "rightringproximal") bones.rightRingProximal = node;
        else if (boneName == "rightringintermediate") bones.rightRingIntermediate = node;
        else if (boneName == "rightringdistal") bones.rightRingDistal = node;
        else if (boneName == "rightlittleproximal") bones.rightLittleProximal = node;
        else if (boneName == "rightlittleintermediate") bones.rightLittleIntermediate = node;
        else if (boneName == "rightlittledistal") bones.rightLittleDistal = node;
    } else if constexpr (has_member_humanoid<AvatarModel>::value) {
        // Newer layout: humanoid.bone_mappings vector
        if (!m.humanoid) m.humanoid = typename decltype(m.humanoid)::value_type{};
        auto& vec = m.humanoid->bone_mappings;

        // Construct a BoneMapping entry and append
        vrm_avatar_model::BoneMapping mapping;
        if constexpr (has_humanoid_bone_enum<>::value) {
            if (auto opt = map_bone_name_to_enum(boneName)) mapping.bone = *opt;
        }
        if constexpr (std::is_assignable_v<decltype(mapping.node), std::string>) {
            mapping.node = std::to_string(node);
        } else {
            mapping.node = static_cast<uint32_t>(node);
        }
        vec.push_back(std::move(mapping));
    } else {
        static_assert(has_member_humanoidBones<AvatarModel>::value || has_member_humanoid<AvatarModel>::value, "Unsupported AvatarModel bone storage for add_bone helper");
    }
}

} // namespace vrm_normalizers::detail


namespace vrm_normalizers {

// Helper function to convert bone name to lowercase for case-insensitive comparison
inline std::string toLower(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return result;
}

// Normalize VRM 0.0 to canonical AvatarModel
inline vrm_avatar_model::AvatarModel NormalizeVrm0ToModel(const vrm_glb_parser::vrm0::VRM& vrm0) {
    vrm_avatar_model::AvatarModel model;
    
    auto& m = model.meta;
    const auto& s = vrm0.meta;

    // Map meta information (version-agnostic)
    vrm_normalizers::detail::assign_meta_identifier(m, s);
    m.version = s.version;
    vrm_normalizers::detail::assign_meta_authors(m, s);
    vrm_normalizers::detail::assign_meta_contact(m, s);
    vrm_normalizers::detail::assign_meta_references(m, s);

    // Map license information in a SFINAE-safe wrapper
    vrm_normalizers::detail::assign_meta_license(m, s);
    
    // Map humanoid bones
    // VRM 0.0 uses a list of bones with string names
    for (const auto& bone : vrm0.humanoid.humanBones) {
        std::string boneName = toLower(bone.bone);

        // Unified setter that handles either HumanoidBones struct or newer vector-style bone_mappings
        vrm_normalizers::detail::add_bone(model, boneName, bone.node);
    }
    
    return model;
}

// Normalize VRM 1.0 to canonical AvatarModel
inline vrm_avatar_model::AvatarModel NormalizeVrm1ToModel(const vrm_glb_parser::vrm1::VRM& vrm1) {
    vrm_avatar_model::AvatarModel model;
    
    // Map meta information (version-agnostic) using local aliases and constexpr guards
    auto& m = model.meta;
    const auto& s = vrm1.meta;

    vrm_normalizers::detail::assign_meta_identifier(m, s);
    m.version = s.version;
    vrm_normalizers::detail::assign_meta_authors(m, s);
    vrm_normalizers::detail::assign_meta_contact(m, s);
    vrm_normalizers::detail::assign_meta_references(m, s);

    // Flat assignments for v1 style fields (shielded)
    if constexpr (vrm_normalizers::detail::has_member_contact_information<decltype(m)>::value) {
        if constexpr (std::is_assignable_v<decltype(m.contact_information), decltype(s.contactInformation)>) {
            m.contact_information = s.contactInformation;
        }
    }
    // Set copyright information if the destination supports it
    vrm_normalizers::detail::set_copyright_information(m, s);

    // Handle license presence (destination may instead use license_type enum)
    vrm_normalizers::detail::assign_meta_license(m, s);

    
    // Map humanoid bones
    // VRM 1.0 has structured bone fields
    const auto& bones = vrm1.humanoid.humanBones;

    // Use unified add_bone helper which handles struct or vector layouts
    vrm_normalizers::detail::add_bone(model, "hips", bones.hips.node);
    vrm_normalizers::detail::add_bone(model, "spine", bones.spine.node);
    if (bones.chest) vrm_normalizers::detail::add_bone(model, "chest", bones.chest->node);
    if (bones.upperChest) vrm_normalizers::detail::add_bone(model, "upperchest", bones.upperChest->node);
    if (bones.neck) vrm_normalizers::detail::add_bone(model, "neck", bones.neck->node);
    vrm_normalizers::detail::add_bone(model, "head", bones.head.node);

    if (bones.leftEye) vrm_normalizers::detail::add_bone(model, "lefteye", bones.leftEye->node);
    if (bones.rightEye) vrm_normalizers::detail::add_bone(model, "righteye", bones.rightEye->node);
    if (bones.jaw) vrm_normalizers::detail::add_bone(model, "jaw", bones.jaw->node);

    vrm_normalizers::detail::add_bone(model, "leftupperleg", bones.leftUpperLeg.node);
    vrm_normalizers::detail::add_bone(model, "leftlowerleg", bones.leftLowerLeg.node);
    vrm_normalizers::detail::add_bone(model, "leftfoot", bones.leftFoot.node);
    if (bones.leftToes) vrm_normalizers::detail::add_bone(model, "lefttoes", bones.leftToes->node);

    vrm_normalizers::detail::add_bone(model, "rightupperleg", bones.rightUpperLeg.node);
    vrm_normalizers::detail::add_bone(model, "rightlowerleg", bones.rightLowerLeg.node);
    vrm_normalizers::detail::add_bone(model, "rightfoot", bones.rightFoot.node);
    if (bones.rightToes) vrm_normalizers::detail::add_bone(model, "righttoes", bones.rightToes->node);

    vrm_normalizers::detail::add_bone(model, "leftupperarm", bones.leftUpperArm.node);
    vrm_normalizers::detail::add_bone(model, "leftlowerarm", bones.leftLowerArm.node);
    vrm_normalizers::detail::add_bone(model, "lefthand", bones.leftHand.node);

    vrm_normalizers::detail::add_bone(model, "rightupperarm", bones.rightUpperArm.node);
    vrm_normalizers::detail::add_bone(model, "rightlowerarm", bones.rightLowerArm.node);
    vrm_normalizers::detail::add_bone(model, "righthand", bones.rightHand.node);

    // Map finger bones
    if (bones.leftThumbMetacarpal) vrm_normalizers::detail::add_bone(model, "leftthumbmetacarpal", bones.leftThumbMetacarpal->node);
    if (bones.leftThumbProximal) vrm_normalizers::detail::add_bone(model, "leftthumbproximal", bones.leftThumbProximal->node);
    if (bones.leftThumbDistal) vrm_normalizers::detail::add_bone(model, "leftthumbdistal", bones.leftThumbDistal->node);
    if (bones.leftIndexProximal) vrm_normalizers::detail::add_bone(model, "leftindexproximal", bones.leftIndexProximal->node);
    if (bones.leftIndexIntermediate) vrm_normalizers::detail::add_bone(model, "leftindexintermediate", bones.leftIndexIntermediate->node);
    if (bones.leftIndexDistal) vrm_normalizers::detail::add_bone(model, "leftindexdistal", bones.leftIndexDistal->node);
    if (bones.leftMiddleProximal) vrm_normalizers::detail::add_bone(model, "leftmiddleproximal", bones.leftMiddleProximal->node);
    if (bones.leftMiddleIntermediate) vrm_normalizers::detail::add_bone(model, "leftmiddleintermediate", bones.leftMiddleIntermediate->node);
    if (bones.leftMiddleDistal) vrm_normalizers::detail::add_bone(model, "leftmiddledistal", bones.leftMiddleDistal->node);
    if (bones.leftRingProximal) vrm_normalizers::detail::add_bone(model, "leftringproximal", bones.leftRingProximal->node);
    if (bones.leftRingIntermediate) vrm_normalizers::detail::add_bone(model, "leftringintermediate", bones.leftRingIntermediate->node);
    if (bones.leftRingDistal) vrm_normalizers::detail::add_bone(model, "leftringdistal", bones.leftRingDistal->node);
    if (bones.leftLittleProximal) vrm_normalizers::detail::add_bone(model, "leftlittleproximal", bones.leftLittleProximal->node);
    if (bones.leftLittleIntermediate) vrm_normalizers::detail::add_bone(model, "leftlittleintermediate", bones.leftLittleIntermediate->node);
    if (bones.leftLittleDistal) vrm_normalizers::detail::add_bone(model, "leftlittledistal", bones.leftLittleDistal->node);

    if (bones.rightThumbMetacarpal) vrm_normalizers::detail::add_bone(model, "rightthumbmetacarpal", bones.rightThumbMetacarpal->node);
    if (bones.rightThumbProximal) vrm_normalizers::detail::add_bone(model, "rightthumbproximal", bones.rightThumbProximal->node);
    if (bones.rightThumbDistal) vrm_normalizers::detail::add_bone(model, "rightthumbdistal", bones.rightThumbDistal->node);
    if (bones.rightIndexProximal) vrm_normalizers::detail::add_bone(model, "rightindexproximal", bones.rightIndexProximal->node);
    if (bones.rightIndexIntermediate) vrm_normalizers::detail::add_bone(model, "rightindexintermediate", bones.rightIndexIntermediate->node);
    if (bones.rightIndexDistal) vrm_normalizers::detail::add_bone(model, "rightindexdistal", bones.rightIndexDistal->node);
    if (bones.rightMiddleProximal) vrm_normalizers::detail::add_bone(model, "rightmiddleproximal", bones.rightMiddleProximal->node);
    if (bones.rightMiddleIntermediate) vrm_normalizers::detail::add_bone(model, "rightmiddleintermediate", bones.rightMiddleIntermediate->node);
    if (bones.rightMiddleDistal) vrm_normalizers::detail::add_bone(model, "rightmiddledistal", bones.rightMiddleDistal->node);
    if (bones.rightRingProximal) vrm_normalizers::detail::add_bone(model, "rightringproximal", bones.rightRingProximal->node);
    if (bones.rightRingIntermediate) vrm_normalizers::detail::add_bone(model, "rightringintermediate", bones.rightRingIntermediate->node);
    if (bones.rightRingDistal) vrm_normalizers::detail::add_bone(model, "rightringdistal", bones.rightRingDistal->node);
    if (bones.rightLittleProximal) vrm_normalizers::detail::add_bone(model, "rightlittleproximal", bones.rightLittleProximal->node);
    if (bones.rightLittleIntermediate) vrm_normalizers::detail::add_bone(model, "rightlittleintermediate", bones.rightLittleIntermediate->node);
    if (bones.rightLittleDistal) vrm_normalizers::detail::add_bone(model, "rightlittledistal", bones.rightLittleDistal->node);
    
    return model;
}

}  // namespace vrm_normalizers
