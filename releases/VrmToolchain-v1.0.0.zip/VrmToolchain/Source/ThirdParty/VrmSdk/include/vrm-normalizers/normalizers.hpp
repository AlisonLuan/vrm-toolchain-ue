#pragma once

#include "vrm_avatar_model/avatar_model.hpp"
#include "vrm-normalizers/result.hpp"
#include <string>
#include <unordered_map>

namespace vrm_normalizers {

// Extension data from parser
struct ExtensionData {
    bool present;
    std::string json_data;
};

// Input map: extension name -> data
using NormalizeInput = std::unordered_map<std::string, ExtensionData>;

// Normalization options
struct NormalizeOptions {
    // BREAKING CHANGE (v0.1): Default changed from false to true.
    // Raw extensions are now preserved by default for maximum data fidelity.
    bool keep_raw_extensions_in_model = true;
    bool strict = false;  // If true, fail on parse warnings; if false, best-effort
};

// Main normalization function: parse raw JSON and produce AvatarModel
Result<vrm_avatar_model::AvatarModel> NormalizeToAvatarModel(
    const NormalizeInput& input,
    const NormalizeOptions& options = NormalizeOptions{}
);

}  // namespace vrm_normalizers
